package tw.com.bais.wechat;

/**
 * Created by xdna on 2016/9/29.
 */
import android.content.Context;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import org.json.JSONObject;
import java.io.UnsupportedEncodingException;
import cz.msebera.android.httpclient.entity.StringEntity;
import cz.msebera.android.httpclient.message.BasicHeader;
import cz.msebera.android.httpclient.protocol.HTTP;

/**
 * Created by xdna on 2016/9/23.
 */
public class RestClient {
    static String TAG = "WeChat2";

    //come from EBusService.java init()
    public static String BASE_URL = "";
    private static AsyncHttpClient client = new AsyncHttpClient();

    public  static void get(String url , RequestParams params , AsyncHttpResponseHandler responseHandler){
        client.get(getAbsoluteUrl( url ), params , responseHandler);
    }

    public static void post(Context context, String url, JSONObject obj , AsyncHttpResponseHandler responseHandler) throws UnsupportedEncodingException {
        StringEntity entity = new StringEntity(obj.toString() , "UTF-8");
        entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        client.post(context , getAbsoluteUrl( url ) , entity ,"application/json", responseHandler);
    }

    public static void put(Context context , String url, JSONObject obj , AsyncHttpResponseHandler responseHandler ) throws UnsupportedEncodingException {
        StringEntity entity = new StringEntity(obj.toString() , "UTF-8");
        entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        client.put(context , getAbsoluteUrl( url ) , entity ,"application/json", responseHandler);
    }

    public static void delete(Context context , String url, JSONObject obj , AsyncHttpResponseHandler responseHandler) throws UnsupportedEncodingException {
        StringEntity entity = new StringEntity(obj.toString() , "UTF-8");
        entity.setContentType(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        client.delete(context , getAbsoluteUrl( url ) , entity ,"application/json", responseHandler);
    }

    private static  String getAbsoluteUrl(String url){
        return  BASE_URL +  url ;
    }

}