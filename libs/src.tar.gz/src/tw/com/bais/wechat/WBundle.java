package tw.com.bais.wechat;

import org.json.JSONObject;

/**
 * Created by xdna on 2016/11/22.
 */

public class WBundle {
    String action = null;
    JSONObject pack = null;
    public WBundle(){}
}
