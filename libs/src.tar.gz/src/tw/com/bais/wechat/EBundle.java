package tw.com.bais.wechat;

import org.json.JSONObject;

/**
 * Created by xdna on 2016/4/28.
 */
public class EBundle {
    int action =0;
    JSONObject settings = null;
    JSONObject pack = null;
    EBundle(){}
}
