package tw.com.bais.wechat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


/**
 * Created by xdna on 2016/9/9.
 */
public class DBOperator {
    final static String TAG = "WeChat2";
    public static String DBName = "wechat";
    public static int DBVersion = 5 ;

    public static String chat_history = "chat_history";
    public static String chat = "chat";
    public static String contacts = "contacts";
    public static String chat_syncts = "chat_syncts";
    public static String chat_openrooms = "chat_openrooms";
    public static String chat_tsflag = "chat_tsflag";
    public static String chat_news = "chat_news";
    public static String chat_settings = "chat_settings";

    public static String owner_id = "";
    public DBHelper dbHelper = null ;
    public static SQLiteDatabase mDB = null;

    public static final String SPSetting = "SPSETTING";
    public static final String SPSettingkey = "wechatSetting";

    public static JSONObject ContactsHashObj = null ;
    public static JSONObject UnReadChatHistoryObj = null ;

    public DBOperator(Context context){
        dbHelper = new DBHelper( context , DBName ,null , DBVersion );
        mDB = dbHelper.getWritableDatabase();
    }

    public static JSONObject getContactsOwnerMid() throws JSONException {
        String sql = "SELECT * from contacts WHERE corps = -1";
        Cursor cursor = mDB.rawQuery( sql , null );

        if (cursor.getCount() > 0){
            JSONObject root = new JSONObject();
            cursor.moveToFirst();
            owner_id = cursor.getString( cursor.getColumnIndex("m_id")) ;
            root.put("m_id" , owner_id );
            root.put("custom_name" ,cursor.getString( cursor.getColumnIndex("custom_name")) ) ;
            root.put("addressbook" ,cursor.getString( cursor.getColumnIndex("addressbook")) );
            Log.d(TAG , "DBOperator getContactsOwnerMid");
            return root ;
        }
        return null ;
    }


    public static boolean contactsExist(JSONObject obj ) throws JSONException {
        if ( mDB != null){
            JSONArray jarr = obj.getJSONArray("data");
            String tmpid = "";

            String owner = EBusService.getSID();

            String sid = jarr.getJSONObject(0).getString("sid");
            String tid = jarr.getJSONObject(0).getString("tid");
            String gid = jarr.getJSONObject(0).getString("gid");
            if (owner.equals( sid ) || sid.equals("WechatAdmin@") ) return true ;

            tmpid = gid.isEmpty() ? sid : gid ;
            String sql = "SELECT * FROM contacts WHERE m_id = ? AND islock = 0";
            Cursor cursor = mDB.rawQuery( sql , new String[]{ tmpid });


            return (cursor.getCount() > 0) ? true : false ;
        }
        return false;
    }

    public static JSONObject contactsExistOwner() throws JSONException {
        if (  mDB != null){
            String sql = "SELECT * FROM contacts WHERE corps = -1";
            Cursor cursor = mDB.rawQuery( sql , null );
            if (cursor.getCount() > 0){
                cursor.moveToFirst();
                JSONObject tmpRecord = new JSONObject();
                tmpRecord.put("m_id", cursor.getString(cursor.getColumnIndex("m_id")));
                tmpRecord.put("custom_name", cursor.getString(cursor.getColumnIndex("custom_name")));
                tmpRecord.put("addressbook", cursor.getString(cursor.getColumnIndex("addressbook")));
                tmpRecord.put("sex", cursor.getString(cursor.getColumnIndex("sex")));
                tmpRecord.put("birth", cursor.getString(cursor.getColumnIndex("birth")));

                tmpRecord.put("email", cursor.getString(cursor.getColumnIndex("email")));
                tmpRecord.put("phone", cursor.getString(cursor.getColumnIndex("phone")));
                tmpRecord.put("mobile", cursor.getString(cursor.getColumnIndex("mobile")));
                tmpRecord.put("grade", cursor.getString(cursor.getColumnIndex("grade")));
                tmpRecord.put("corps", cursor.getInt(cursor.getColumnIndex("corps")));

                tmpRecord.put("islock", cursor.getInt(cursor.getColumnIndex("islock")));
                tmpRecord.put("isgroup", cursor.getInt(cursor.getColumnIndex("isgroup")));
                tmpRecord.put("xgroup", cursor.getString(cursor.getColumnIndex("xgroup")));
                tmpRecord.put("peonums", cursor.getInt(cursor.getColumnIndex("peonums")));
                tmpRecord.put("picture_path", cursor.getString(cursor.getColumnIndex("picture_path")));

                tmpRecord.put("created_time", cursor.getString(cursor.getColumnIndex("created_time")));
                tmpRecord.put("updated_time", cursor.getString(cursor.getColumnIndex("updated_time")));
                tmpRecord.put("contact_id", cursor.getString(cursor.getColumnIndex("contact_id")));
                tmpRecord.put("contact_key", cursor.getString(cursor.getColumnIndex("contact_key")));
                tmpRecord.put("status_msg", cursor.getString(cursor.getColumnIndex("status_msg")));

                tmpRecord.put("ulast_updated_time", cursor.getString(cursor.getColumnIndex("ulast_updated_time")));
                tmpRecord.put("glast_updated_time", cursor.getString(cursor.getColumnIndex("glast_updated_time")));
                tmpRecord.put("others", cursor.getString(cursor.getColumnIndex("others")));

                return tmpRecord;
            }else{
                return  null ;
            }
        }

        return null;
    }

    public static boolean contactsIns (JSONObject obj) throws JSONException {
        Log.d(TAG , "enter contactsIns ");
        if ( mDB != null){

            //delete
            if ( obj.getInt("corps") == -1) {
                owner_id = obj.getString("m_id") ;
                String delSql = "DELETE FROM contacts WHERE  corps = -1 ";
                mDB.execSQL( delSql );
            }else{
                String delSql = "DELETE FROM contacts WHERE m_id = ? ";
                mDB.execSQL( delSql , new String[]{ obj.getString("m_id") } );
            }

            ContentValues cv = new ContentValues();
            cv.put("m_id",obj.getString("m_id"));
            cv.put("custom_name",obj.getString("custom_name"));
            cv.put("addressbook",obj.getString("addressbook"));
            cv.put("sex",obj.getString("sex"));
            cv.put("birth",obj.getString("birth"));


            cv.put("email",obj.getString("email"));
            cv.put("phone",obj.getString("phone"));
            cv.put("mobile",obj.getString("mobile"));
            cv.put("grade",obj.getString("grade"));
            cv.put("corps",obj.getInt("corps"));


            cv.put("islock",obj.getInt("islock"));
            cv.put("isgroup",obj.getInt("isgroup"));
            cv.put("xgroup",obj.getString("xgroup"));
            cv.put("peonums",obj.getInt("peonums"));
            cv.put("picture_path",obj.getString("picture_path"));

            cv.put("created_time",obj.getString("created_time"));
            cv.put("updated_time",obj.getString("updated_time"));
            cv.put("contact_id",obj.getString("contact_id"));
            cv.put("contact_key",obj.getString("contact_key"));
            cv.put("status_msg",obj.getString("status_msg"));

            cv.put("ulast_updated_time",obj.getString("ulast_updated_time"));
            cv.put("glast_updated_time",obj.getString("glast_updated_time"));
            cv.put("others",obj.getString("others"));
            //cv.put("gid",obj.getString("gid"));

            mDB.insert(contacts, null, cv);

            Log.d(TAG , "contactsIns success");
            Log.d(TAG ,obj.getString("created_time")  );
            return  true;                                                                                                                                                   
        }
        Log.d(TAG , "enter contactsIns false");
        return  false;
    }

    public static boolean contactsUpd(JSONObject obj) throws JSONException {
        if ( mDB != null) {
            ContentValues cv = new ContentValues();
            String m_id = obj.getString("m_id");
            cv.put("m_id", m_id);
            cv.put("custom_name",obj.getString("custom_name"));
            cv.put("addressbook",obj.getString("addressbook"));
            cv.put("sex",obj.getString("sex") );
            cv.put("birth",obj.getString("birth"));


            cv.put("email",obj.getString("email"));
            cv.put("phone",obj.getString("phone"));
            cv.put("mobile",obj.getString("mobile"));
            cv.put("grade",obj.getString("grade"));
            cv.put("corps",obj.getInt("corps"));


            cv.put("islock",obj.getInt("islock"));
            cv.put("isgroup",obj.getInt("isgroup"));
            cv.put("xgroup",obj.getString("xgroup"));
            cv.put("peonums",obj.getInt("peonums"));
            cv.put("picture_path",obj.getString("picture_path"));

            cv.put("created_time",obj.getString("created_time"));
            cv.put("updated_time",obj.getString("updated_time"));
            cv.put("contact_id",obj.getString("contact_id"));
            cv.put("contact_key",obj.getString("contact_key"));
            cv.put("status_msg",obj.getString("status_msg"));

            cv.put("ulast_updated_time",obj.getString("ulast_updated_time"));
            cv.put("glast_updated_time",obj.getString("glast_updated_time"));
            cv.put("others",obj.getString("others"));

            mDB.update(contacts, cv, "m_id=?", new String[]{m_id});
            Log.d(TAG, "contactsUpdate success");
            return true;
        }
        return false;
    }

    public static boolean contactsDel(JSONObject obj) throws JSONException {
        if ( mDB != null) {
            String m_id = obj.has("m_id")? obj.getString("m_id"): "" ;
            String action = obj.has("action") ? obj.getString("action"):"";
            int corps = obj.has("corps") ? obj.getInt("corps"): -99 ;

            String sql;
            if (action.equals("delall")){
                mDB.delete("contacts", null , null );
                Log.d(TAG , "delall");

            }else if ( action.equals("delallExcOwner")) {
                mDB.delete("contacts", "corps!=?", new String[]{"-1"});
                Log.d(TAG, "delallExcOwner");

            }else if ( action.equals("delcorps")) {
                mDB.delete("contacts", "corps =?", new String[]{ String.valueOf( corps )});
                Log.d(TAG, "delcorps");

            }else{
                mDB.delete("contacts","m_id=?" , new String[]{ m_id });
                Log.d(TAG , "delete");
            }

            Log.d(TAG , "contactsDelete success");
            return true;
        }
        return false;
    }


    public static JSONObject getContactsGroup() throws JSONException {
        if ( mDB != null) {
            JSONObject root = new JSONObject();
            JSONArray jarr = new JSONArray();
            String sql = "SELECT * FROM contacts WHERE isgroup = 1 AND islock = 0";
            Cursor cursor = mDB.rawQuery(sql, null);

            if (cursor.getCount() > 0) {
                cursor.moveToFirst();
                while (!cursor.isAfterLast()) {
                    JSONObject tmpRecord = new JSONObject();

                    tmpRecord.put("m_id", cursor.getString(cursor.getColumnIndex("m_id")));
                    tmpRecord.put("custom_name", cursor.getString(cursor.getColumnIndex("custom_name")));
                    tmpRecord.put("addressbook", cursor.getString(cursor.getColumnIndex("addressbook")));
                    tmpRecord.put("sex", cursor.getString(cursor.getColumnIndex("sex")));
                    tmpRecord.put("birth", cursor.getString(cursor.getColumnIndex("birth")));

                    tmpRecord.put("email", cursor.getString(cursor.getColumnIndex("email")));
                    tmpRecord.put("phone", cursor.getString(cursor.getColumnIndex("phone")));
                    tmpRecord.put("mobile", cursor.getString(cursor.getColumnIndex("mobile")));
                    tmpRecord.put("grade", cursor.getString(cursor.getColumnIndex("grade")));
                    tmpRecord.put("corps", cursor.getInt(cursor.getColumnIndex("corps")));

                    tmpRecord.put("islock", cursor.getInt(cursor.getColumnIndex("islock")));
                    tmpRecord.put("isgroup", cursor.getInt(cursor.getColumnIndex("isgroup")));
                    tmpRecord.put("xgroup", cursor.getString(cursor.getColumnIndex("xgroup")));
                    tmpRecord.put("peonums", cursor.getInt(cursor.getColumnIndex("peonums")));
                    tmpRecord.put("picture_path", cursor.getString(cursor.getColumnIndex("picture_path")));

                    tmpRecord.put("created_time", cursor.getString(cursor.getColumnIndex("created_time")));
                    tmpRecord.put("updated_time", cursor.getString(cursor.getColumnIndex("updated_time")));
                    tmpRecord.put("contact_id", cursor.getString(cursor.getColumnIndex("contact_id")));
                    tmpRecord.put("contact_key", cursor.getString(cursor.getColumnIndex("contact_key")));
                    tmpRecord.put("status_msg", cursor.getString(cursor.getColumnIndex("status_msg")));

                    tmpRecord.put("ulast_updated_time", cursor.getString(cursor.getColumnIndex("ulast_updated_time")));
                    tmpRecord.put("glast_updated_time", cursor.getString(cursor.getColumnIndex("glast_updated_time")));
                    tmpRecord.put("others", cursor.getString(cursor.getColumnIndex("others")));

                    jarr.put(tmpRecord);
                    cursor.moveToNext();
                }

                root.put("data", jarr);
                root.put("length", jarr.length());
                return root;
            }
        }

        return  null ;
    }

    public static JSONObject getContactsUser(JSONObject obj ) throws JSONException {
        if ( mDB != null) {

            try {
                JSONObject root = new JSONObject();
                JSONArray jarr = new JSONArray();
                String sql="";
                Cursor cursor = null ;

                if ( obj.has("corps")  ) {
                    sql = "SELECT * FROM contacts WHERE corps = " + obj.getInt("corps") ;
                    cursor = mDB.rawQuery(sql, null);
                    Log.d(TAG , "DBOperator getContactsUser -->xcorps:"+obj.getInt("corps") );
                }else if ( obj.has("m_id") ){
                    sql = "SELECT * FROM contacts WHERE m_id = ?";
                    cursor = mDB.rawQuery( sql , new String[]{ obj.getString("m_id")} );
                    Log.d(TAG , "DBOperator getContactsUser -->m_id:" + obj.getString("m_id") );
                }else {
                    sql = "SELECT * FROM contacts ORDER BY corps ASC";
                    cursor = mDB.rawQuery( sql , null );
                    Log.d(TAG , "DBOperator getContactsUser -->get all");
                }

                if (cursor.getCount() != 0) {
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast()) {
                        JSONObject tmpRecord = new JSONObject();
                        tmpRecord.put("m_id", cursor.getString(cursor.getColumnIndex("m_id")));
                        tmpRecord.put("custom_name", cursor.getString(cursor.getColumnIndex("custom_name")));
                        tmpRecord.put("addressbook", cursor.getString(cursor.getColumnIndex("addressbook")));
                        tmpRecord.put("sex", cursor.getString(cursor.getColumnIndex("sex")));
                        tmpRecord.put("birth", cursor.getString(cursor.getColumnIndex("birth")));

                        tmpRecord.put("email", cursor.getString(cursor.getColumnIndex("email")));
                        tmpRecord.put("phone", cursor.getString(cursor.getColumnIndex("phone")));
                        tmpRecord.put("mobile", cursor.getString(cursor.getColumnIndex("mobile")));
                        tmpRecord.put("grade", cursor.getString(cursor.getColumnIndex("grade")));
                        tmpRecord.put("corps", cursor.getInt(cursor.getColumnIndex("corps")));

                        tmpRecord.put("islock", cursor.getInt(cursor.getColumnIndex("islock")));
                        tmpRecord.put("isgroup", cursor.getInt(cursor.getColumnIndex("isgroup")));
                        tmpRecord.put("xgroup", cursor.getString(cursor.getColumnIndex("xgroup")));
                        tmpRecord.put("peonums", cursor.getInt(cursor.getColumnIndex("peonums")));
                        tmpRecord.put("picture_path", cursor.getString(cursor.getColumnIndex("picture_path")));

                        tmpRecord.put("created_time", cursor.getString(cursor.getColumnIndex("created_time")));
                        tmpRecord.put("updated_time", cursor.getString(cursor.getColumnIndex("updated_time")));
                        tmpRecord.put("contact_id", cursor.getString(cursor.getColumnIndex("contact_id")));
                        tmpRecord.put("contact_key", cursor.getString(cursor.getColumnIndex("contact_key")));
                        tmpRecord.put("status_msg", cursor.getString(cursor.getColumnIndex("status_msg")));

                        tmpRecord.put("ulast_updated_time", cursor.getString(cursor.getColumnIndex("ulast_updated_time")));
                        tmpRecord.put("glast_updated_time", cursor.getString(cursor.getColumnIndex("glast_updated_time")));
                        tmpRecord.put("others", cursor.getString(cursor.getColumnIndex("others")));

                        jarr.put(tmpRecord);
                        cursor.moveToNext();
                    }
                }

                root.put("data", jarr);
                root.put("length", jarr.length());
                Log.d(TAG , "DBOperator getContactsUser-->finish") ;
                return root;
            }catch (Exception e){
                Log.d(TAG , "DBOperator getContactsUser Exception");
                return null;
            }
        }
        return null;
    }


    public static JSONObject getContactsData() throws JSONException {
        if ( mDB != null) {
            if (ContactsHashObj == null){
                //get all user data
                JSONObject filter = new JSONObject();
                ContactsHashObj = getContactsUser(filter);
            }

            return ContactsHashObj;
        }
        return  null;
    }


    public static JSONObject getContactsData( String key ) throws JSONException {
        if ( mDB != null) {
            if (ContactsHashObj == null){
                //get all user data
                JSONObject filter = new JSONObject();
                ContactsHashObj = getContactsUser(filter);
            }

            //Log.d(TAG, "DBOperator getContactsData Data-------------->" + ContactsHashObj.toString() );
            JSONObject obj = null;
            JSONArray jarr = ContactsHashObj.getJSONArray("data");
            for (int i=0 ; i < jarr.length() ; i++) {
                String m_id = jarr.getJSONObject(i).getString("m_id");

                if (key.equals( m_id )) {
                    obj = jarr.getJSONObject(i);
                    break ;
                }
            }
            //Log.d(TAG, "DBOperator getContactsData return -------------->" + obj.toString() );
            Log.d(TAG, "DBOperator getContactsData DATA m_id:" + key );
            return  obj ;
        }
        return  null;
    }


    public static JSONObject getContactsGroupData() throws JSONException {
        if ( mDB != null) {
            if (ContactsHashObj == null){
                //get all user data
                JSONObject filter = new JSONObject();
                ContactsHashObj = getContactsUser(filter);
            }

            JSONObject obj = new JSONObject();
            JSONArray jarr = ContactsHashObj.getJSONArray("data");
            JSONArray parr = new JSONArray();
            for (int i=0 ; i < jarr.length() ; i++) {
                Integer isgroup = jarr.getJSONObject(i).getInt("isgroup");

                if ( isgroup == 1) {
                    obj = jarr.getJSONObject(i);
                    parr.put( obj );
                }
            }

            obj.put("data",parr);
            return  obj ;
        }
        return  null;
    }


    public static boolean chatHistoryReReaded(JSONObject obj) throws JSONException {
        if ( mDB != null){

            Log.d(TAG , obj.toString() );
            JSONArray jarr = obj.getJSONArray("data");
            for (int i=0 ; i < jarr.length() ; i++){
                String cid = jarr.getJSONObject(i).getString("cid");
                String sql = "UPDATE " + chat_history + " SET status = 1 WHERE cid = ? AND flag = -1 ";
                mDB.execSQL( sql , new String[]{ cid});
            }

            UnReadChatHistoryObj = null ;
            return true;
        }
        return false;
    }


    public static int chatHistoryReReaded(String channel) throws JSONException {
        if (mDB != null){
            ContentValues cv = new ContentValues();
            cv.put("status" , 1);
            int num = mDB.update("chat_history", cv, "action='send' AND flag=-1 AND channel=?" , new String[]{ channel });
            Log.d(TAG ,"DBOeprator chatHistoryReReaded channel " + channel + " readed");

            UnReadChatHistoryObj = null ;
            return num;
        }
        return 0;
    }


    public static boolean chatHistoryUpdInsert( JSONObject obj ) throws JSONException {
        if (mDB != null){
            JSONArray  jarr = obj.getJSONArray( "data");

            for (int i = 0; i < jarr.length(); i++){
                ContentValues cv = new ContentValues();
                String cid = jarr.getJSONObject(i).getString("cid");
                cv.put("cid", cid);
                cv.put("channel", jarr.getJSONObject(i).getString("channel"));
                cv.put("action", jarr.getJSONObject(i).getString("action"));
                cv.put("sid", jarr.getJSONObject(i).getString("sid"));
                cv.put("tid", jarr.getJSONObject(i).getString("tid"));

                cv.put("gid", jarr.getJSONObject(i).getString("gid"));
                cv.put("corps", jarr.getJSONObject(i).getInt("corps"));
                cv.put("category", jarr.getJSONObject(i).getString("category"));
                cv.put("data", jarr.getJSONObject(i).getString("data"));
                cv.put("created_time", jarr.getJSONObject(i).getString("created_time"));

                cv.put("updated_time", jarr.getJSONObject(i).getString("updated_time"));
                cv.put("location_name", jarr.getJSONObject(i).getString("location_name"));
                cv.put("location_address", jarr.getJSONObject(i).getString("location_address"));
                cv.put("location_phone", jarr.getJSONObject(i).getString("location_phone"));
                cv.put("location_latitude", jarr.getJSONObject(i).getInt("location_latitude"));

                cv.put("location_longitude", jarr.getJSONObject(i).getInt("location_longitude"));
                cv.put("flag", jarr.getJSONObject(i).getInt("flag"));


                String sql = "SELECT * FROM chat_history WHERE cid = ?";
                Cursor cursor = mDB.rawQuery(sql ,new String[]{ cid } );
                if ( cursor.getCount() == 0 ){
                    Log.d(TAG , "cursorCount=" + jarr.getJSONObject(i).getInt("status"));
                    //insert
                    cv.put("status", 0);
                    mDB.insert("chat_history" , null , cv );
                }else{
                    Log.d(TAG , "not cursorCount=" + jarr.getJSONObject(i).getInt("status"));
                    //update
                    mDB.update("chat_history" ,cv , "cid=?", new String[]{ cid });
                }

            }

            Log.d(TAG , "DBOperator chatHistoryUpdInsert");
            //save unread record
            UnReadChatHistoryObj = null ;
            return  true ;
        }
        return false ;
    }


    public static boolean chatHistoryUpdInsert( JSONObject obj ,boolean isreaded ) throws JSONException {
        if (mDB != null){
            JSONArray  jarr = obj.getJSONArray( "data");

            for (int i = 0; i < jarr.length(); i++){
                ContentValues cv = new ContentValues();

                String cid = jarr.getJSONObject(i).getString("cid");
                String sql = "SELECT * FROM chat_history WHERE cid = ?";
                Cursor cursor = mDB.rawQuery(sql ,new String[]{ cid } );

                cv.put("cid", cid);
                cv.put("channel", jarr.getJSONObject(i).getString("channel"));
                cv.put("action", jarr.getJSONObject(i).getString("action"));
                cv.put("sid", jarr.getJSONObject(i).getString("sid"));
                cv.put("tid", jarr.getJSONObject(i).getString("tid"));

                cv.put("gid", jarr.getJSONObject(i).getString("gid"));
                cv.put("corps", jarr.getJSONObject(i).getInt("corps"));
                cv.put("category", jarr.getJSONObject(i).getString("category"));
                cv.put("data", jarr.getJSONObject(i).getString("data"));
                cv.put("created_time", jarr.getJSONObject(i).getString("created_time"));

                cv.put("updated_time", jarr.getJSONObject(i).getString("updated_time"));
                cv.put("location_name", jarr.getJSONObject(i).getString("location_name"));
                cv.put("location_address", jarr.getJSONObject(i).getString("location_address"));
                cv.put("location_phone", jarr.getJSONObject(i).getString("location_phone"));
                cv.put("location_latitude", jarr.getJSONObject(i).getInt("location_latitude"));

                cv.put("location_longitude", jarr.getJSONObject(i).getInt("location_longitude"));
                cv.put("flag", jarr.getJSONObject(i).getInt("flag"));


                if ( cursor.getCount() == 0 ){
                    if (isreaded){
                        cv.put("status", 1);
                    }else{
                        //insert
                        cv.put("status", 0);
                    }
                    mDB.insert("chat_history" , null , cv );

                }else{
                    if (isreaded){
                        cv.put("status", 1);
                    }
                    //update
                    mDB.update("chat_history" ,cv , "cid=?", new String[]{ cid });
                }
            }

            //save unread record
            UnReadChatHistoryObj = null ;
            return  true ;
        }
        return false ;
    }

    public static boolean isSyncTsInit(){
        Log.d(TAG , "DBOperator getSyncTsInit");
        if (mDB != null){
            String SID = EBusService.getSID();
            if (SID.isEmpty()){
                return false;
            }else{
                String sql = "SELECT * FROM chat_syncts WHERE channel = ? AND action='send' AND initial = 1";
                Cursor cursor = mDB.rawQuery(sql, new String[]{ SID });
                return (cursor.getCount() == 0) ? false : true ;
            }
        }
        return false ;
    }

    public static void setChatSynTs(JSONObject obj ) throws JSONException {
        if ( mDB != null){
            String SID = EBusService.getSID();

            JSONArray jsonArr = obj.getJSONArray("data");
            //sorted last_created_time ***********************************************************
            JSONArray sortedJsonArray = new JSONArray();
            List<JSONObject> jsonValues = new ArrayList<JSONObject>();
            for (int i = 0; i < jsonArr.length(); i++) {
                jsonValues.add(jsonArr.getJSONObject(i));
            }
            Collections.sort( jsonValues, new Comparator<JSONObject>() {
                //You can change "Name" with "ID" if you want to sort by ID
                private static final String KEY_NAME = "updated_time";

                @Override
                public int compare(JSONObject a, JSONObject b) {
                    String valA = new String();
                    String valB = new String();

                    try {
                        valA = (String) a.get(KEY_NAME);
                        valB = (String) b.get(KEY_NAME);
                    }
                    catch (JSONException e) {
                        //do something
                    }

                    return valA.compareTo(valB);
                    //if you want to change the sort order, simply use the following:
                    //return -valA.compareTo(valB);
                }
            });
            //End sorted last_created_time ********************************************************

            String lastchnn="";
            for (int i=0 ; i < jsonArr.length() ; i++) {
                String channel = jsonArr.getJSONObject(i).getString("channel");
                String action = jsonArr.getJSONObject(i).getString("action");
                String updated_time = jsonArr.getJSONObject(i).getString("updated_time");
                String gid = jsonArr.getJSONObject(i).getString("gid");


                //self update
                if (gid.isEmpty()){
                    ContentValues cv = new ContentValues();
                    cv.put("last_updated_time", updated_time );
                    //mDB.insert("chat_syncts" , null , cv );
                    mDB.update("chat_syncts", cv , "channel=? AND action=?", new String[]{ SID , action});

                }else{ //group
                    JSONObject xobj = getContactsData( gid );
                    ContentValues cv = new ContentValues();
                    cv.put("channel" , gid );
                    cv.put("action", action );
                    cv.put("last_updated_time", updated_time );

                    //add
                    if ( xobj == null){
                        mDB.insert("chat_syncts" , null , cv );
                    }else{ //update
                        mDB.update("chat_syncts", cv , "channel=? AND action=?", new String[]{ SID , action});
                    }
                }

            }

            ContentValues cv = new ContentValues();
            cv.put("channel" , EBusService.getSID() );
            cv.put("action","notify");
            cv.put("last_updated_time", "" );
            cv.put("isgroup" , 0 );

            cv.put("initial" , 0 );
            mDB.insert("chat_syncts" , null , cv );
        }
    }


    //getLastRecord insert syncts  for "send" action
    public static void refSyncts(){
        if (mDB != null){
            String SID = EBusService.getSID();

            String sql = "SELECT * FROM chat_syncts";
            Cursor cursor = mDB.rawQuery( sql , null );
            if (cursor.getCount() == 0 )  return  ;

            cursor.moveToFirst();
            while (! cursor.isAfterLast()){
                String channel = cursor.getString( cursor.getColumnIndex("channel"));
                String action = cursor.getString( cursor.getColumnIndex("action"));
                String last_updated_time = cursor.getString( cursor.getColumnIndex("last_updated_time"));
                int isgroup = cursor.getInt( cursor.getColumnIndex("isgroup"));

                //self chat_syncts---> channel is sid
                if (channel.equals( SID)){
                    //send
                    String sql2 = "SELECT * FROM chat_history WHERE action='" + action +"' AND channel LIKE '%" + SID + "%' ORDER BY updated_time DESC LIMIT 0,1";
                    Cursor cursor2 = mDB.rawQuery(sql2 , null );
                    if (cursor2.getCount() > 0 ){
                        cursor2.moveToFirst();
                        ContentValues cv2 = new ContentValues();
                        String action2 = cursor2.getString( cursor2.getColumnIndex("action"));
                        cv2.put("last_updated_time", cursor2.getString(cursor2.getColumnIndex("updated_time")));
                        cv2.put("initial", 1 );
                        mDB.update( "chat_syncts" , cv2 , "channel=? AND action=?" , new String[]{ SID, action2 });
                        Log.d(TAG , "chat_syncts self update");
                    }

                }else{ //group
                    String sql3 = "SELECT * FROM chat_history WHERE action='"+action+"' AND channel='"+ channel + "' ORDER BY updated_time DESC LIMIT 0,1";
                    Cursor cursor3 = mDB.rawQuery(sql3 , null );
                    if (cursor3.getCount() > 0 ){
                        cursor3.moveToFirst();
                        ContentValues cv3 = new ContentValues();
                        String action3 = cursor3.getString(cursor3.getColumnIndex("action"));
                        cv3.put("last_updated_time", cursor3.getString(cursor3.getColumnIndex("updated_time")));
                        cv3.put("initial", 1 );
                        mDB.update( "chat_syncts" , cv3 , "channel=? AND action=?" , new String[]{ channel, action3 });
                        Log.d(TAG , "chat_syncts group update");
                    }
                }

                cursor.moveToNext();
            }

            Log.d(TAG , "DBOperator refreshSyncts success");
        }
    }


    public static int getHistoryUnreadCount(){
        if (mDB != null){
            String sql = "SELECT * FROM chat_history WHERE action='send' AND status=0 AND flag=-1" ;
            Cursor cursor = mDB.rawQuery(sql , null );
            return cursor.getCount() ;
        }
        return 0;
    }
    //test group
    public static JSONObject chatHistoryQueryUnread2(int offset,int limit) throws JSONException {
        if ( mDB != null ){
            JSONObject root = new JSONObject();
            JSONArray jarr = new JSONArray();
            JSONArray reverseArr = new JSONArray();
            String sql = "SELECT * FROM chat_history WHERE action='send' AND status=0 AND flag=-1 ORDER BY channel ASC, updated_time DESC limit ?,?";
            Cursor cursor = mDB.rawQuery( sql , new String[]{  String.valueOf(offset) ,  String.valueOf( limit ) } );

            if (cursor.getCount() > 0 ) {
                cursor.moveToFirst();
                while (!cursor.isAfterLast()) {
                    JSONObject tmprow = new JSONObject();
                    tmprow.put("cid", cursor.getString(cursor.getColumnIndex("cid")));
                    tmprow.put("channel", cursor.getString(cursor.getColumnIndex("channel")));
                    tmprow.put("action", cursor.getString(cursor.getColumnIndex("action")));
                    tmprow.put("sid", cursor.getString(cursor.getColumnIndex("sid")));
                    tmprow.put("tid", cursor.getString(cursor.getColumnIndex("tid")));

                    tmprow.put("gid", cursor.getString(cursor.getColumnIndex("gid")));
                    tmprow.put("category", cursor.getString(cursor.getColumnIndex("category")));
                    tmprow.put("corps", cursor.getString(cursor.getColumnIndex("corps")));
                    tmprow.put("data", cursor.getString(cursor.getColumnIndex("data")));
                    tmprow.put("status", cursor.getString(cursor.getColumnIndex("status")));

                    tmprow.put("created_time", cursor.getString(cursor.getColumnIndex("created_time")));
                    tmprow.put("updated_time", cursor.getString(cursor.getColumnIndex("updated_time")));
                    tmprow.put("location_name", cursor.getString(cursor.getColumnIndex("location_name")));
                    tmprow.put("location_address", cursor.getString(cursor.getColumnIndex("location_address")));
                    tmprow.put("location_phone", cursor.getString(cursor.getColumnIndex("location_phone")));

                    tmprow.put("location_latitude", cursor.getInt(cursor.getColumnIndex("location_latitude")));
                    tmprow.put("location_longitude", cursor.getInt(cursor.getColumnIndex("location_longitude")));
                    tmprow.put("flag", cursor.getInt(cursor.getColumnIndex("flag")));

                    jarr.put(tmprow);
                    cursor.moveToNext();
                }

                //reverse
                reverseArr = new JSONArray();
                for (int i = (jarr.length() - 1); i >= 0; i--) {
                    reverseArr.put(jarr.getJSONObject(i));
                }
            }
            root.put("data", reverseArr);
            root.put("length", jarr.length());

            UnReadChatHistoryObj = root ;
            return root;
        }
        return null;
    }

    public static JSONObject getUnreadRecordFilter(JSONObject obj) throws JSONException {
        if ( mDB != null){
            int count = 0;
            JSONObject root = new JSONObject();
            JSONArray  jsonArr = new JSONArray();

            JSONArray jarr = obj.getJSONArray("data");
            for (int i=0 ; i < jarr.length() ; i++){
                count ++ ;
                String channel = jarr.getJSONObject(i).getString("channel");
                String sid = jarr.getJSONObject(i).getString("sid");
                String tid = jarr.getJSONObject(i).getString("tid");
                String gid = jarr.getJSONObject(i).getString("gid");
                String data = jarr.getJSONObject(i).getString("data");
                String updated_time = jarr.getJSONObject(i).getString("updated_time");
                int isgroup = gid.isEmpty() ? 0 : 1;
                String m_id = (isgroup == 1) ? gid : sid ;

                JSONObject contacts = getContactsData( m_id );
                if ( contacts == null ) continue;
                String custom_name = contacts.getString("custom_name");
                String peonums = contacts.getString("peonums");

                //next record
                int nextcount= i+1;
                if ( nextcount < jarr.length()){
                    String nextchann = jarr.getJSONObject( nextcount ).getString("channel");

                    //unread last record
                    if ( ! channel.equals( nextchann )){
                        JSONObject tmprow = new JSONObject();
                        tmprow.put("channel", channel);
                        tmprow.put("sid", sid);
                        tmprow.put("tid", tid);
                        tmprow.put("gid", gid);
                        tmprow.put("data", "");
                        tmprow.put("last_message", data );
                        tmprow.put("last_created_time", updated_time);
                        tmprow.put("isgroup" , isgroup);

                        tmprow.put("chat_name", custom_name);
                        tmprow.put("peonums", peonums);
                        tmprow.put("unread", count);

                        jsonArr.put( tmprow);
                        count = 0;
                    }

                }else{ //END record
                    JSONObject tmprow = new JSONObject();
                    tmprow.put("channel", channel);
                    tmprow.put("sid", sid);
                    tmprow.put("tid", tid);
                    tmprow.put("gid", gid);
                    tmprow.put("data", "");
                    tmprow.put("last_message", data );
                    tmprow.put("last_created_time", updated_time);
                    tmprow.put("isgroup" , isgroup);

                    tmprow.put("chat_name", custom_name);
                    tmprow.put("peonums", peonums);
                    tmprow.put("unread", count);

                    jsonArr.put( tmprow);
                }
            }


            //sorted last_created_time ***********************************************************
            JSONArray sortedJsonArray = new JSONArray();
            List<JSONObject> jsonValues = new ArrayList<JSONObject>();
            for (int i = 0; i < jsonArr.length(); i++) {
                jsonValues.add(jsonArr.getJSONObject(i));
            }
            Collections.sort( jsonValues, new Comparator<JSONObject>() {
                //You can change "Name" with "ID" if you want to sort by ID
                private static final String KEY_NAME = "last_created_time";

                @Override
                public int compare(JSONObject a, JSONObject b) {
                    String valA = new String();
                    String valB = new String();

                    try {
                        valA = (String) a.get(KEY_NAME);
                        valB = (String) b.get(KEY_NAME);
                    }
                    catch (JSONException e) {
                        //do something
                    }

                    return -valA.compareTo(valB);
                    //if you want to change the sort order, simply use the following:
                    //return -valA.compareTo(valB);
                }
            });
            //End sorted last_created_time ********************************************************

            root.put( "data" , jsonArr );
            return  root ;
        }
        return  null;
    }

    public static JSONObject chatLastQuery3() throws JSONException {
        if (mDB != null ){
            try {
                String sql = "SELECT * FROM  ( SELECT * FROM chat_history WHERE flag = -1 AND action='send' ORDER BY updated_time) temp GROUP BY channel ORDER BY updated_time DESC";
                Cursor cursor = mDB.rawQuery(sql , null );
                if ( cursor.getCount() > 0 ){
                    JSONObject root = new JSONObject();
                    JSONArray  jarr = new JSONArray();
                    int count = 0 ;
                    cursor.moveToFirst();
                    String last_mid = "";
                    while (! cursor.isAfterLast()){
                        JSONObject tmprow = new JSONObject();
                        String channel = cursor.getString(cursor.getColumnIndex("channel"));
                        String sid = cursor.getString(cursor.getColumnIndex("sid"));
                        String tid = cursor.getString(cursor.getColumnIndex("tid"));
                        String gid = cursor.getString(cursor.getColumnIndex("gid"));
                        String data = cursor.getString(cursor.getColumnIndex("data"));
                        String updated_time = cursor.getString(cursor.getColumnIndex("updated_time"));
                        int flag = cursor.getInt(cursor.getColumnIndex("flag"));
                        int isgroup = gid.isEmpty() ? 0 : 1;

                        tmprow.put("channel", channel);
                        tmprow.put("sid", sid);
                        tmprow.put("tid", tid);
                        tmprow.put("gid", gid);
                        tmprow.put("data", "");
                        tmprow.put("last_message", data );
                        tmprow.put("last_created_time", updated_time);
                        tmprow.put("isgroup" , isgroup);

                        String m_id = (isgroup == 1) ? gid : sid ;

                        JSONObject contacts = getContactsData( m_id );

                        if ( contacts == null  ){
                            contacts.put("custom_name", "none");
                            contacts.put("peonums", 0 );
                        }

                        String custom_name = contacts.getString("custom_name");
                        int peonums = contacts.getInt("peonums");

                        //unread rows
                        String sqlunread = "SELECT * FROM chat_history WHERE action='send' AND status=0 AND flag=-1 AND channel='" + channel + "'";
                        Cursor cursor2 = mDB.rawQuery( sqlunread , null );
                        count = cursor2.getCount();


                        tmprow.put("chat_name", custom_name);
                        tmprow.put("peonums", peonums);
                        tmprow.put("unread", count);
                        jarr.put(tmprow);

                        cursor.moveToNext();
                    }

                    root.put("data" , jarr );
                    Log.d(TAG , "chatLastQuery3 -->finish");
                    return root ;
                }
            }catch (Exception e){
                Log.d(TAG , "DBOperator chatLastQuery3 Exception");
                return  null;
            }
        }
        return  null ;
    }



    public static int chatHistoryDel( JSONObject obj ) throws JSONException {
        if (mDB != null){
            if (obj.has("channel")){
                String channel = obj.getString("channel");
                int num = mDB.delete("chat_history","channel=?", new String[]{ channel });
                Log.d(TAG , "chatHistoryDel:" + num );
                return  num;
            }

            if (obj.has("cid")){
                String cid = obj.getString("cid");
                int num = mDB.delete("chat_history","cid=?", new String[]{ cid });
                Log.d(TAG , "chatHistoryDel:" + num );
                return  num;
            }
        }
        return  0 ;
    }

    public static JSONObject chatHistoryQueryDBDate(JSONObject obj) throws JSONException {
        if ( mDB != null) {
            String  channel = obj.getString("channel");

            int offset = obj.has("offset") ?  obj.getInt("offset"): 0 ;
            int limit = obj.has("limit") ?  obj.getInt("limit"): 50 ;

            JSONObject root = new JSONObject();
            JSONArray jarr = new JSONArray();
            JSONArray reverseArr = new JSONArray();

            String sql = "SELECT * FROM chat_history WHERE action='send' AND channel = ? AND flag=-1 ORDER BY updated_time DESC LIMIT ?,?";
            Cursor cursor = mDB.rawQuery( sql , new String[]{ channel , String.valueOf(offset) , String.valueOf(limit) } ) ;

            if (cursor.getCount() > 0){
                cursor.moveToFirst();
                while(! cursor.isAfterLast()) {
                    JSONObject tmprow = new JSONObject();
                    tmprow.put("cid" , cursor.getString( cursor.getColumnIndex("cid") ));
                    tmprow.put("channel" , cursor.getString( cursor.getColumnIndex("channel") ));
                    tmprow.put("action" , cursor.getString( cursor.getColumnIndex("action") ));
                    tmprow.put("sid" , cursor.getString( cursor.getColumnIndex("sid") ));
                    tmprow.put("tid" , cursor.getString( cursor.getColumnIndex("tid") ));

                    tmprow.put("gid" , cursor.getString( cursor.getColumnIndex("gid") ));
                    tmprow.put("corps" , cursor.getString( cursor.getColumnIndex("corps") ));
                    tmprow.put("category" , cursor.getString( cursor.getColumnIndex("category") ));
                    tmprow.put("data" , cursor.getString( cursor.getColumnIndex("data") ));
                    tmprow.put("status" , cursor.getString( cursor.getColumnIndex("status")));

                    tmprow.put("created_time" , cursor.getString( cursor.getColumnIndex("created_time")));
                    tmprow.put("updated_time" , cursor.getString( cursor.getColumnIndex("updated_time")));
                    tmprow.put("location_name" , cursor.getString( cursor.getColumnIndex("location_name")));
                    tmprow.put("location_address" , cursor.getString( cursor.getColumnIndex("location_address")));
                    tmprow.put("location_phone" , cursor.getString( cursor.getColumnIndex("location_phone")));

                    tmprow.put("location_latitude" , cursor.getInt( cursor.getColumnIndex("location_latitude")));
                    tmprow.put("location_longitude" , cursor.getInt( cursor.getColumnIndex("location_longitude")));
                    tmprow.put("flag" , cursor.getInt( cursor.getColumnIndex("flag")));

                    jarr.put( tmprow );
                    cursor.moveToNext();
                }

                //reverse
                reverseArr = new JSONArray();
                for (int i= (jarr.length()-1); i >= 0 ;i--){
                        reverseArr.put( jarr.getJSONObject(i) );
                }
            }

            root.put("data", reverseArr );
            root.put("length", jarr.length());

            return root ;
        }
        return null;
    }


    public static JSONObject chatHistoyUndelivered() throws JSONException {
        if ( mDB != null){
            JSONObject root = new JSONObject();
            JSONArray  jarr = new JSONArray();

            String sql = "SELECT * FROM chat_history WHERE flag > -1 ";
            Cursor cursor = mDB.rawQuery(sql , null );
            if (cursor.getCount() >0 ){
                cursor.moveToFirst();
                while (!cursor.isAfterLast()){
                    JSONObject tmprow = new JSONObject();
                    tmprow.put("cid" , cursor.getString( cursor.getColumnIndex("cid") ));
                    tmprow.put("channel" , cursor.getString( cursor.getColumnIndex("channel") ));
                    tmprow.put("action" , cursor.getString( cursor.getColumnIndex("action") ));
                    tmprow.put("sid" , cursor.getString( cursor.getColumnIndex("sid") ));
                    tmprow.put("tid" , cursor.getString( cursor.getColumnIndex("tid") ));

                    tmprow.put("gid" , cursor.getString( cursor.getColumnIndex("gid") ));
                    tmprow.put("corps" , cursor.getString( cursor.getColumnIndex("corps") ));
                    tmprow.put("category" , cursor.getString( cursor.getColumnIndex("category") ));
                    tmprow.put("data" , cursor.getString( cursor.getColumnIndex("data") ));
                    tmprow.put("status" , cursor.getString( cursor.getColumnIndex("status")));

                    tmprow.put("created_time" , cursor.getString( cursor.getColumnIndex("created_time")));
                    tmprow.put("updated_time" , cursor.getString( cursor.getColumnIndex("updated_time")));
                    tmprow.put("location_name" , cursor.getString( cursor.getColumnIndex("location_name")));
                    tmprow.put("location_address" , cursor.getString( cursor.getColumnIndex("location_address")));
                    tmprow.put("location_phone" , cursor.getString( cursor.getColumnIndex("location_phone")));

                    tmprow.put("location_latitude" , cursor.getInt( cursor.getColumnIndex("location_latitude")));
                    tmprow.put("location_longitude" , cursor.getInt( cursor.getColumnIndex("location_longitude")));
                    tmprow.put("flag" , cursor.getInt( cursor.getColumnIndex("flag")));

                    jarr.put( tmprow );
                    cursor.moveToNext();
                }
            }

            root.put("data" , jarr);
            root.put("length", jarr.length());
            return  root ;
        }
        return null;
    }


    public static int  getChatHistoryUnReadCount(){
        if (mDB != null){
            String sql = "SELECT * FROM chat_history WHERE flag = -1 AND action='send' AND status=0";
            Cursor cursor = mDB.rawQuery(sql , null );
            return  cursor.getCount();
        }
        return -1;
    }

    //save
    public static void openRoomsUpdInsert(JSONObject obj) throws JSONException {
        if (mDB != null){
            JSONArray jarr = obj.getJSONArray("data");
            for (int i=0 ; i < jarr.length() ; i++){
                String channel = jarr.getJSONObject(i).getString("channel");
                String sid = jarr.getJSONObject(i).getString("sid");
                String starttime = jarr.getJSONObject(i).getString("starttime");
                String endtime = jarr.getJSONObject(i).getString("endtime");

                ContentValues cv = new ContentValues();
                cv.put("channel" , channel);
                cv.put("sid" , sid);
                cv.put("starttime" , starttime );
                cv.put("endtime" , endtime );

                String sql = "SELECT * FROM chat_openrooms WHERE channel = ? AND sid =?";
                Cursor cursor = mDB.rawQuery(sql ,new String[]{ channel , sid}) ;
                if (cursor.getCount() == 0 ){
                    mDB.insert("chat_openrooms" , null , cv);
                }else{
                    mDB.update("chat_openrooms" , cv , "channel=? AND sid=?" , new String[]{channel , sid});
                }
            }

            Log.d(TAG , "DBOperator openRoomsUpdInsert success");
        }
    }

    //getOpenRooms
    public static JSONObject getOpenRooms(JSONObject obj ) throws JSONException {
        if (mDB != null){
            String channel = obj.getString("channel");
            String sid = obj.getString("sid");
            String sql = null ;
            Cursor cursor = null;
            JSONObject root = new JSONObject();
            JSONArray  jarr = new JSONArray();

            if (channel.contains("@")){
                sql = "SELECT * FROM chat_openrooms WHERE channel = ?";
                cursor = mDB.rawQuery(sql , new String[]{ channel} );
            }else{
                sql = "SELECT * FROM chat_openrooms WHERE channel=? ANd sid=?";
                cursor = mDB.rawQuery(sql , new String[]{ channel , sid } );
            }

            if (cursor.getCount() == 0){
                root.put("data" , jarr);
                root.put("length", jarr.length() );
            }else{
                cursor.moveToFirst();
                while (! cursor.isAfterLast()){
                    JSONObject tmprow = new JSONObject();
                    tmprow.put("channel" , cursor.getString( cursor.getColumnIndex("channel")));
                    tmprow.put("sid" , cursor.getString( cursor.getColumnIndex("sid")));
                    tmprow.put("starttime" , cursor.getString( cursor.getColumnIndex("starttime")));
                    tmprow.put("endtime" , cursor.getString( cursor.getColumnIndex("endtime")));

                    jarr.put(tmprow);
                    cursor.moveToNext();
                }

                root.put("data" , jarr);
                root.put("length", jarr.length() );
            }

            return  root;
        }
        return null;
    }


    public  static  JSONObject SyncChatTS() throws JSONException {
        if (mDB != null){
            String sql = "SELECT * FROM contacts WHERE islock = 0 AND (isgroup = 1 OR corps = -1) ORDER BY  isgroup ";
            Cursor cursor = mDB.rawQuery( sql , null );
            if (cursor.getCount() == 0 )  return null ;

            cursor.moveToFirst();
            String OwnerUpdatedTime = "";
            //action send
            while (! cursor.isAfterLast() ){
                String m_id = cursor.getString(cursor.getColumnIndex("m_id"));
                int isgroup = cursor.getInt( cursor.getColumnIndex("isgroup"));
                int corps =  cursor.getInt( cursor.getColumnIndex("corps"));
                String updated_time = cursor.getString( cursor.getColumnIndex("updated_time"));

                //owner
                if ( corps == -1 )  OwnerUpdatedTime = updated_time ;

                String sql2 = "";
                if (isgroup == 1){
                    sql2 = "SELECT * FROM chat_syncts WHERE channel='" + m_id + "'" ;
                }else{
                    sql2 = "SELECT * FROM chat_syncts WHERE channel LIKE '%" + m_id + "%'" ;
                }

                Cursor cursor2 = mDB.rawQuery( sql2 , null ) ;
                if (cursor2.getCount() == 0){
                    ContentValues cv = new ContentValues();
                    cv.put("channel" , m_id );
                    cv.put("action","send");
                    cv.put("last_updated_time", updated_time );
                    cv.put("isgroup" , isgroup );
                    cv.put("initial" , 0 );
                    mDB.insert("chat_syncts" , null , cv );
                }
                cursor.moveToNext();
            }

            //invite
            String sql3= "SELECT * FROM chat_syncts WHERE action='invite'";
            Cursor cursor3 = mDB.rawQuery( sql3 , null);
            if ( cursor3.getCount() == 0){
                ContentValues cv = new ContentValues();
                cv.put("channel" , EBusService.getSID() );
                cv.put("action","invite");
                cv.put("last_updated_time", OwnerUpdatedTime );
                cv.put("isgroup" , 0 );
                cv.put("initial" , 0 );
                mDB.insert("chat_syncts" , null , cv );
            }

            //notify
            String sql4= "SELECT * FROM chat_syncts WHERE action='notify'";
            Cursor cursor4 = mDB.rawQuery( sql4 , null);
            if ( cursor4.getCount() == 0){
                ContentValues cv = new ContentValues();
                cv.put("channel" , EBusService.getSID() );
                cv.put("action","notify");
                cv.put("last_updated_time", OwnerUpdatedTime );
                cv.put("isgroup" , 0 );
                cv.put("initial" , 0 );
                mDB.insert("chat_syncts" , null , cv );
            }

            JSONObject root = new JSONObject();
            JSONArray  jarr = new JSONArray();
            String sql5 = "SELECT * FROM chat_syncts ORDER BY action";
            Cursor cursor5 = mDB.rawQuery(sql5 , null );

            int taskcount = cursor5.getCount();
            if ( taskcount > 0 ) {
                cursor5.moveToFirst();
                while (!cursor5.isAfterLast()) {
                    JSONObject tmprow = new JSONObject();
                    tmprow.put("channel", cursor5.getString(cursor5.getColumnIndex("channel")));
                    tmprow.put("action", cursor5.getString(cursor5.getColumnIndex("action")));
                    tmprow.put("last_updated_time", cursor5.getString(cursor5.getColumnIndex("last_updated_time")));
                    tmprow.put("isgroup", cursor5.getInt(cursor5.getColumnIndex("isgroup")));
                    tmprow.put("initial", cursor5.getInt(cursor5.getColumnIndex("initial")));
                    //
                    tmprow.put("taskcount", taskcount );
                    jarr.put(tmprow);
                    cursor5.moveToNext();
                }
                root.put("data", jarr);
                root.put("length", jarr.length());
            }

            Log.d(TAG, "DBOperator SyncChatTS:"+ root.toString());
            return  root;
        }
        return  null ;
    }


    //crudNews
    public static JSONObject crudNews(JSONObject obj ) throws JSONException {
        if (mDB != null){
            String action = obj.has("action") ?obj.getString("action"):"";
            String xday = ( System.currentTimeMillis() - 56*24*60*60*1000 ) + "";

            if (action.equals("insert")) {
                //delete day14 record
                mDB.delete("chat_news","created_time < ?" , new String[]{ xday } );
                Log.d(TAG , "DBPOperator delete less than 8 weeks");

                JSONArray jarr = obj.getJSONArray("data");

                for (int i=0 ; i < jarr.length() ; i++){
                    String title = jarr.getJSONObject(i).getString("title");
                    String content = jarr.getJSONObject(i).getString("content");
                    String created_time = jarr.getJSONObject(i).getString("created_time");

                    ContentValues cv = new ContentValues();
                    cv.put("title" , title);
                    cv.put("content" , content);
                    cv.put("created_time" , created_time);

                    mDB.insert("chat_news", null , cv);
                }
                return null ;
            }

            if (action.equals("query") ){
                Log.d(TAG , "DBOperator crudNews enter query");
                int offset = obj.has("offset") ? obj.getInt("offset") : 0 ;
                int limit = obj.has("limit") ? obj.getInt("limit") : 10 ;
                JSONObject root = new JSONObject();
                JSONArray  jarr = new JSONArray();

                String sql = "SELECT * FROM chat_news ORDER BY created_time DESC LIMIT ?,?";
                Cursor cursor = mDB.rawQuery( sql , new String[]{ String.valueOf( offset) , String.valueOf(limit)} );

                if (cursor.getCount() > 0 ){
                    cursor.moveToFirst();
                    while (!cursor.isAfterLast()){
                        String title = cursor.getString( cursor.getColumnIndex("title"));
                        String content = cursor.getString( cursor.getColumnIndex("content"));
                        String created_time = cursor.getString( cursor.getColumnIndex("created_time"));

                        JSONObject tmprecord = new JSONObject();
                        tmprecord.put("title" , title );
                        tmprecord.put("content" , content );
                        tmprecord.put("created_time" , created_time );
                        jarr.put( tmprecord );
                        cursor.moveToNext();
                    }

                    root.put("data" , jarr );
                    return  root ;
                }
            }
        }
        return null;
    }

    //crudTsFlag
    public static JSONObject crudChatTsFlag(JSONObject obj ) throws JSONException {
        if (mDB != null){
            String action = obj.has("action") ?obj.getString("action"):"";
            String flag = obj.has("flag") ? obj.getString("flag"): "" ;
            String ts = obj.has("ts") ? obj.getString("ts"): "" ;

            if (action.equals("insert") || action.equals("update")) {
                mDB.delete("chat_tsflag","flag=?" , new String[]{ flag } );

                ContentValues cv = new ContentValues();
                cv.put("flag" ,  flag );
                cv.put("ts" , ts );
                mDB.insert("chat_tsflag" ,null , cv );
                JSONObject root = new JSONObject();
                return root;
            }

            if (action.equals("query") ){
                Log.d(TAG , "DBOperator enter query");
                String sql = "SELECT * FROM chat_tsflag WHERE flag = ?";
                Cursor cursor = mDB.rawQuery(sql, new String[]{ flag });
                if (cursor.getCount() > 0 ){
                    cursor.moveToFirst();
                    String xflag = cursor.getString( cursor.getColumnIndex("flag"));
                    String xts = cursor.getString( cursor.getColumnIndex("ts"));
                    JSONObject  root = new JSONObject();
                    root.put("flag" , xflag );
                    root.put("ts" , xts );
                    return  root ;
                }
            }
        }
        return null;
    }

    //crud chat_settings /
    public static int saveChatSettings(JSONObject obj ) throws JSONException {
        if (mDB != null){
            int code = 0;
            String sql = "SELECT * FROM chat_settings WHERE id = '" + DBName + "'";
            Cursor cursor = mDB.rawQuery(sql, null );
            ContentValues cv = new ContentValues();
            cv.put("id" , DBName );
            cv.put("serverip" ,  obj.getString("serverip") );
            cv.put("port" ,  obj.getInt("port") );
            cv.put("notifyTarget" ,  obj.getString("notifyTarget") );

            cv.put("hasNotify" ,  obj.getInt("hasNotify") );
            cv.put("notifyTitle" ,  obj.getString("notifyTitle") );
            cv.put("notifyTicker" ,  obj.getString("notifyTicker") );

            cv.put("hasVibrate" ,  obj.getInt("hasVibrate") );
            cv.put("hasSound" ,  obj.getInt("hasSound") );
            cv.put("hasSaveEl" ,  obj.getInt("hasSaveEl") );
            cv.put("key" ,  obj.getString("key") );
            cv.put("fontSize" ,  obj.getInt("fontSize") );

            if (cursor.getCount() >0 ) {
                //update
                code = mDB.update("chat_settings", cv, "id=?", new String[]{DBName});
            }else{
                //insert
                code = (int) mDB.insert("chat_settings", null , cv );
            }
            Log.d(TAG , "DBOperator saveChatSettings success");
            return  code ;
        }
        return -1;
    }


    //resetdb
    public static boolean ResetDB(JSONObject obj) throws JSONException {
        if (mDB != null){
            String[] arr= obj.getString("db").split("\\|");

            for (int i=0 ; i < arr.length ; i++){
                if ( arr[i].equals("ChatHistory") ){
                    mDB.delete( chat_history , null ,null );
                    continue;
                }
                if ( arr[i].equals("Contacts") ){
                    mDB.delete( contacts , null ,null );
                    continue;
                }
                if ( arr[i].equals("OpenRooms") ){
                    mDB.delete( chat_openrooms , null ,null );
                }
                if ( arr[i].equals("ChatNews") ){
                    mDB.delete( chat_news , null ,null );
                    continue;
                }
                if ( arr[i].equals("ChatTsFlag") ){
                    mDB.delete( chat_tsflag , null ,null );
                    continue;
                }
                if ( arr[i].equals("ChatSyncTs") ){
                    mDB.delete( chat_syncts , null ,null );
                    continue;
                }
            }

            //mDB.delete( chat_settings , null ,null );
            Log.d(TAG , "DBOperator ResetDB success ");
            return  true;
        }
        return false ;
    }

    //checkChatHistory
    public static JSONObject chkChatHistory(JSONObject obj) throws JSONException {
        String cid = EBusService.getCID();
        obj.remove("cid");
        obj.put("cid", cid);

        String channel = obj.has("channel") ? obj.getString("channel") : "";
        obj.remove("channel");
        obj.put("channel", channel);

        String action = obj.has("action") ? obj.getString("action") : "";
        obj.remove("action");
        obj.put("action", action);

        String sid = obj.has("sid") ? obj.getString("sid") : "";
        obj.remove("sid");
        obj.put("sid", sid);

        String tid = obj.has("tid") ? obj.getString("tid") : "";
        obj.remove("tid");
        obj.put("tid", tid);


        String gid = obj.has("gid") ? obj.getString("gid") : "";
        obj.remove("gid");
        obj.put("gid", gid);


        int corps = obj.has("corps") ? obj.getInt("corps") : 0;
        obj.remove("corps");
        obj.put("corps", corps);


        String category = obj.has("category") ? obj.getString("category") : "";
        obj.remove("category");
        obj.put("category", category);

        String data = obj.has("data") ? obj.getString("data") : "";
        obj.remove("data");
        obj.put("data", data);


        int status = obj.has("status") ? obj.getInt("status") : 0;
        obj.remove("status");
        obj.put("status", status);


        String created_time = obj.has("created_time") ? obj.getString("created_time") : "";
        obj.remove("created_time");
        obj.put("created_time", created_time);

        String updated_time = obj.has("updated_time") ? obj.getString("updated_time") : "";
        obj.remove("updated_time");
        obj.put("updated_time", updated_time);

        String location_name = obj.has("location_name") ? obj.getString("location_name") : "";
        obj.remove("location_name");
        obj.put("location_name", location_name);

        String location_address = obj.has("location_address") ? obj.getString("location_address") : "";
        obj.remove("location_address");
        obj.put("location_address", location_address);

        String location_phone = obj.has("location_phone") ? obj.getString("location_phone") : "";
        obj.remove("location_phone");
        obj.put("location_phone", location_phone);


        int location_latitude = obj.has("location_latitude") ? obj.getInt("location_latitude") : 0;
        obj.remove("location_latitude");
        obj.put("location_latitude", location_latitude);


        int location_longitude = obj.has("location_longitude") ? obj.getInt("location_longitude") : 0;
        obj.remove("location_longitude");
        obj.put("location_longitude", location_longitude);

        int flag = obj.has("flag") ? obj.getInt("flag") : 0;
        obj.remove("flag");
        obj.put("flag", flag);

        return obj ;
    }


    //checkContacsData
    public static JSONObject chkContacts(JSONObject obj) throws JSONException {
        String action = obj.has("action") ? obj.getString("action") : "";
        obj.remove("action");
        obj.put("action",action);

        String m_id = obj.has("m_id") ? obj.getString("m_id") : "";
        obj.remove("m_id");
        obj.put("m_id",m_id);

        String custom_name = obj.has("custom_name") ? obj.getString("custom_name") : "";
        obj.remove("custom_name");
        obj.put("custom_name",custom_name);

        String addressbook = obj.has("addressbook") ? obj.getString("addressbook") : "";
        obj.remove("addressbook");
        obj.put("addressbook",addressbook);

        String sex = obj.has("sex") ? obj.getString("sex") : "";
        obj.remove("sex");
        obj.put("sex",sex);

        String birth = obj.has("birth") ? obj.getString("birth") : "";
        obj.remove("birth");
        obj.put("birth",birth);



        String email = obj.has("email") ? obj.getString("email") : "";
        obj.remove("email");
        obj.put("email",email);

        String phone = obj.has("phone") ? obj.getString("phone") : "";
        obj.remove("phone");
        obj.put("phone",phone);

        String grade = obj.has("grade") ? obj.getString("grade") : "";
        obj.remove("grade");
        obj.put("grade",grade);

        String mobile = obj.has("mobile") ? obj.getString("mobile") : "";
        obj.remove("mobile");
        obj.put("mobile",mobile);

        int corps = obj.has("corps") ? obj.getInt("corps") : 0 ;
        obj.remove("corps");
        obj.put("corps",corps);



        int islock = obj.has("islock") ? obj.getInt("islock") : 0 ;
        obj.remove("islock");
        obj.put("islock",islock);

        int isgroup = obj.has("isgroup") ? obj.getInt("isgroup") : 0 ;
        obj.remove("isgroup");
        obj.put("isgroup",isgroup);

        String xgroup = obj.has("xgroup") ? obj.getString("xgroup") : "";
        obj.remove("xgroup");
        obj.put("xgroup",xgroup);

        int peonums = obj.has("peonums") ? obj.getInt("peonums") : 0;
        obj.remove("peonums");
        obj.put("peonums",peonums);

        String picture_path = obj.has("picture_path") ? obj.getString("picture_path") : "";
        obj.remove("picture_path");
        obj.put("picture_path",picture_path);



        String created_time = obj.has("created_time") ? obj.getString("created_time") : "";
        obj.remove("created_time");
        obj.put("created_time",created_time);

        String updated_time = obj.has("updated_time") ? obj.getString("updated_time") : "";
        obj.remove("updated_time");
        obj.put("updated_time", updated_time );

        String contact_id = obj.has("contact_id") ? obj.getString("contact_id") : "";
        obj.remove("contact_id");
        obj.put("contact_id",contact_id);

        String contact_key = obj.has("contact_key") ? obj.getString("contact_key") : "";
        obj.remove("contact_key");
        obj.put("contact_key",contact_key);

        String status_msg = obj.has("status_msg") ? obj.getString("status_msg") : "";
        obj.remove("status_msg");
        obj.put("status_msg",status_msg);


        String ulast_updated_time = obj.has("ulast_updated_time") ? obj.getString("status_msg") : "";
        obj.remove("ulast_updated_time");
        obj.put("ulast_updated_time",ulast_updated_time);

        String glast_updated_time = obj.has("glast_updated_time") ? obj.getString("glast_updated_time") : "";
        obj.remove("glast_updated_time");
        obj.put("glast_updated_time",glast_updated_time);

        String others = obj.has("others") ? obj.getString("others") : "";
        obj.remove("others");
        obj.put("others",others);

        Log.d(TAG , "m_id is " + m_id );
        Log.d(TAG , "custom_name is " + custom_name );
        if (action.isEmpty() ) return null ;

        return obj;
    }


    //check
    public static JSONObject checkChatSettings(JSONObject obj) throws JSONException {
        String serverip = obj.has("serverip")  ? obj.getString("serverip") : "wechat.ebais.com.tw";
        obj.remove("serverip");
        obj.put("serverip",serverip);

        int port = obj.has("port") ? obj.getInt("port") : 3002 ;
        obj.remove("port");
        obj.put("port",port);

        String notifyTarget = obj.has("notifyTarget") ? obj.getString("notifyTarget") : "tw.com.bais.ichat.MainActivity";
        obj.remove("notifyTarget");
        obj.put("notifyTarget",notifyTarget);

        int hasNotify = obj.has("hasNotify") ? obj.getInt("hasNotify"):1;
        obj.remove("hasNotify");
        obj.put("hasNotify",hasNotify);

        String notifyTitle = obj.has("notifyTitle") ? obj.getString("notifyTitle") : "";
        obj.remove("notifyTitle");
        obj.put("notifyTitle",notifyTitle);

        String notifyTicker = obj.has("notifyTicker") ? obj.getString("notifyTicker") : "";
        obj.remove("notifyTicker");
        obj.put("notifyTicker",notifyTicker);


        int hasVibrate = obj.has("hasVibrate") ? obj.getInt("hasVibrate") : 0;
        obj.remove("hasVibrate");
        obj.put("hasVibrate",hasVibrate);

        int hasSound = obj.has("hasSound") ? obj.getInt("hasSound") : 0;
        obj.remove("hasSound");
        obj.put("hasSound",hasSound);

        int hasSaveEl = obj.has("hasSaveEl") ? obj.getInt("hasSaveEl") : 0;
        obj.remove("hasSaveEl");
        obj.put("hasSaveEl",hasSaveEl);


        String key = obj.has("key") ? obj.getString("key") : "1qaz2wsx3edc4rfv5tgb6yhn7ujm8ik";
        obj.remove("key");
        obj.put("key",key);

        int fontSize = obj.has("fontSize") ? obj.getInt("fontSize") : 16 ;
        obj.remove("fontSize");
        obj.put("fontSize",fontSize);

        Log.d(TAG , "DBOperator checkChatSettings");
        return obj;
    }
}
