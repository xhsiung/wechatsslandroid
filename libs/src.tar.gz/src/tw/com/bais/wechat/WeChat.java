package tw.com.bais.wechat;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.provider.Settings;
import android.util.Log;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;
import org.apache.cordova.PluginResult;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class WeChat extends CordovaPlugin{
    final static String TAG = "WeChat2";
    static int activeInstance = 0 ;
    public static final String SPSetting = "SPSETTING";
    public static final String SPSettingkey = "wechatSetting";


    String filterAction = "tw.com.bais.wechat.WeChat";
    NetworkInfo mNetworkInfo = null;
    BroadcastReceiver receiver = null;
    CallbackContext  myCallbackContext= null;
    Activity context;
    CordovaWebView webView;


    public DBOperator dbOperator = null ;

    boolean checkSyncTsInit = true;

    int socketErrTimes = 0;

    static boolean isActive(){
        return (activeInstance > 0);
    }

    @Override
    public void initialize(CordovaInterface cordova, CordovaWebView webView) {
        super.initialize(cordova, webView);

        activeInstance++ ;
        context = cordova.getActivity();
        this.webView = webView ;

        EventBus.getDefault().register(this);
        if (DBOperator.mDB == null){
            dbOperator = new DBOperator( context );
        }

        EBusService.TaskCount = 0 ;
    }

    @Override
    protected void pluginInitialize() {
        //super.pluginInitialize();
    }

    @Override
    public boolean execute(String action, JSONArray args, final CallbackContext callbackContext) throws JSONException {
        initNetworkInfo();
        //network
//        if (mNetworkInfo == null || !mNetworkInfo.isAvailable()) {
//            EBusService.mSocket =  null;
//            Log.d(TAG , "WeChat execute mNetworkInfo error");
//        }

        //start reciever
        if (action.equals("start")){
            Log.d(TAG , "start_test");
            //enable service
            sendService( context );

            if (this.myCallbackContext != null){
                callbackContext.error("listener already running");
                return  true;
            }
            this.myCallbackContext =  callbackContext ;
            startReceiver();

            PluginResult result = new PluginResult(PluginResult.Status.NO_RESULT);
            //keep status callback
            result.setKeepCallback(true);
            callbackContext.sendPluginResult(result);

            //send broadcast read data
            //Intent intent = new Intent();
            //intent.setAction("tw.com.bais.wechat.BootReceiver");
            //context.sendBroadcast(intent);
            //Log.d(TAG ,"start_test sendBroadcast");

            //offline or diconnected server
            if (mNetworkInfo == null || !mNetworkInfo.isAvailable() || DBOperator.isSyncTsInit() ){
                cordova.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(3000);
                            JSONObject jobj = DBOperator.chatLastQuery3();
                            Log.d(TAG , "WeChat offline or initial syncts ever to get DBOperator.chatLastQuery3");
                            WeChat.this.webView.loadUrl("javascript: wechatOnUnReadChatInitInterface("+ jobj + ")");
                            checkSyncTsInit = false ;
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                });

            }

            return true;
        }

        //stop reciever
        if (action.equals("stop")){
            Log.d(TAG , "stop reciever");
            stopReceiver();
            if (this.myCallbackContext != null) {
                PluginResult result = new PluginResult(PluginResult.Status.OK, new JSONObject());
                // release status callback in JS side
                result.setKeepCallback(false);
                this.myCallbackContext.sendPluginResult(result);
            }
            this.myCallbackContext = null ;
            callbackContext.success();
            return true;
        }

        //send broadcast
        if (action.equals("sendBroadcast")){
            Log.d(TAG, "sendBroadcast enter");
            //corodva exec ---> [arg0]
            JSONObject obj = args.getJSONObject(0);
            //sendBroadcast
            Intent intent = new Intent();
            intent.putExtra("data", obj.toString());
            intent.setAction( filterAction );
            cordova.getActivity().sendBroadcast(intent, null);

            callbackContext.success("sendBroadcast callback");
            return true;
        }


        //initConn
        if (action.equals("initConn")){
            SetInitConn();
            return true;
        }

        if (action.equals("connect")){
            EBundle eb = new EBundle();
            eb.action =  EBusService.CONNECT;
            sendService( context , eb );
            return true;
        }

        if (action.equals("disconnect")){
            EBundle eb = new EBundle();
            eb.action =  EBusService.DISCONNECT;
            sendService( context , eb );
            return true;
        }

        if (action.equals("subscribe")){
            JSONObject obj = args.getJSONObject(0);
            sendSubscribe( obj , true );
            return true;
        }

        if (action.equals("unsubscribe")){
            JSONObject obj = args.getJSONObject(0);
            sendSubscribe( obj , false );
            return true;
        }

        if (action.equals("multiSubscribe")){
            JSONObject obj = args.getJSONObject(0);
            sendMultiSubscribe( obj , true );
            return true;
        }

        if (action.equals("multiUnSubscribe")){
            JSONObject obj = args.getJSONObject(0);
            sendMultiSubscribe( obj , false );
            return true;
        }


        if (action.equals("secretInvite")){
            JSONObject obj = args.getJSONObject(0);
            EBundle eb = new EBundle();
            eb.action =  EBusService.SECRETINVITE;
            eb.pack = obj;
            sendService( context , eb );
            return true;
        }

        if (action.equals("notify")){
            JSONObject obj = args.getJSONObject(0);
            EBundle eb = new EBundle();
            eb.action =  EBusService.NOTIFYSEND;
            eb.pack = obj;
            sendService( context , eb );
            return true;
        }


        //return loopback save
        if (action.equals("loopback")){
            JSONObject obj = args.getJSONObject(0);
            EBundle eb = new EBundle();
            eb.action = EBusService.LOOPBACK ;
            eb.pack = obj;
            sendService( context , eb);
            return true;
        }

        //getDeviceID
        if (action.equals("deviceid")){
            callbackContext.success( getDeviceID() );
            return  true;
        }

        //openrooms
        if ( action.equals("openrooms")){
            Log.d(TAG , "Wechat openrooms");
            JSONObject obj = args.getJSONObject(0);
            EBundle eb = new EBundle();
            eb.action =  EBusService.OPENROOMS;
            eb.pack = obj;
            sendService( context , eb );
            return true;
        }

        //sendStopService
        if ( action.equals("stopService")){
            Log.d(TAG , "Wechat stopService");
            sendStopService();
            return true;
        }

        //sendStartService
        if ( action.equals("startService")){
            Log.d(TAG , "Wechat startService");
            sendStartService();
            return true;
        }


        if (action.equals("clear")){
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        EBusService.SID = "";
                        EBusService.TaskCount = 0 ;
                        checkSyncTsInit = true ;
                        if (EBusService.isActive()) {
                            EBusService.UnSubcribeAll();
                        }

                        Log.d(TAG, "WeChat Clear");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

            return true;
        }

        //isConnected
        if (action.equals("isConnected")){
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if ( EBusService.mSocket == null ) {
                        callbackContext.success( 0 );
                    }else{
                        if (EBusService.mSocket.connected()){
                            callbackContext.success( 1 );
                        }else{
                            callbackContext.success( 0 );
                        }
                    }
                }
            });
            return true;
        }

        //saveChatSettings
        if (action.equals("saveChatSettings")){
            JSONObject obj = args.getJSONObject(0);
            JSONObject xobj = DBOperator.checkChatSettings( obj );

            //save SharePreference
            Log.d(TAG , "WeChat saveChatSettings:" + xobj.toString() );
            saveChatSettingsSharePre( xobj );

            return true;
        }


        //getChatSettings
        if (action.equals("getChatSettings")){
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject xobj = getChatSettingsSharePre() ;

                        if ( xobj ==  null) {
                            callbackContext.success( new JSONObject("{}"));
                        }else{
                            Log.d(TAG , "getChatSettings:" + xobj.toString());
                            callbackContext.success(xobj);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            return true;
        }

        //crudNews
        if (action.equals("crudNews")){
            final JSONObject obj = args.getJSONObject(0);
            final String xaction = obj.getString("action");
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                try {
                    if ( xaction.equals("insert") ){
                        JSONObject  xobj = DBOperator.crudNews( obj );
                        JSONObject root = new JSONObject();
                        callbackContext.success( root );
                     }

                    if (xaction.equals("query")){
                        JSONObject  xobj = DBOperator.crudNews( obj );
                        if (xobj != null ){
                            callbackContext.success( xobj );
                        }
                    }

                } catch (JSONException e) {
                    e.printStackTrace();
                }
                }
            });
            return true;
        }


        //crudTsFlag
        if (action.equals("crudTsFlag")){
            final JSONObject obj = args.getJSONObject(0);
            final String xaction = obj.getString("action");

            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (xaction.equals("update") || xaction.equals("insert") ){
                            JSONObject  xobj = DBOperator.crudChatTsFlag( obj );
                            if (xobj != null ){
                                callbackContext.success( xobj );
                            }
                        }

                        if (xaction.equals("query")){
                            JSONObject  xobj = DBOperator.crudChatTsFlag( obj );
                            if (xobj != null ){
                                callbackContext.success( xobj );
                            }
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });
            return true;
        }


        //resetdb
        if (action.equals("resetdb")){
            final JSONObject obj = args.getJSONObject(0);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if ( ! DBOperator.ResetDB( obj )) {
                            callbackContext.error("error");
                        }
                    } catch (JSONException e) {
                        Log.d(TAG , "WeChat resetdb error");
                    }
                }
            });
            return true;
        }

        //undelivered
        if (action.equals("undelivered")){
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject obj  = DBOperator.chatHistoyUndelivered();
                        if ( obj != null ){
                            callbackContext.success( obj );
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            return true;
        }

        if (action.equals("send")){
            JSONObject obj = args.getJSONObject(0);
            String xaction = obj.getString("action");
            String xcid = obj.has("cid") ? obj.getString("cid"): "";

            //action:send save sqlite tmpdb
                if (xaction.equals("send") && xcid.isEmpty() ){
                final JSONObject xobj = DBOperator.chkChatHistory( obj );
                //action:send --> save tmpsqlite
                cordova.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            JSONObject root = new JSONObject();
                            JSONArray jarr = new JSONArray();
                            jarr.put( xobj );
                            root.put("data", jarr);
                            Log.d(TAG , root.toString() );
                            DBOperator.chatHistoryUpdInsert( root );
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }


            //send service
            EBundle eb = new EBundle();
            eb.action =  EBusService.SEND;
            eb.pack = obj;
            sendService( context , eb );
            return true;
        }


        if (action.equals("del_chat_history")){
            final JSONObject xobj = args.getJSONObject(0);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        int num = DBOperator.chatHistoryDel( xobj );
                        callbackContext.success( num );

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

            return true;
        }

        if (action.equals("querydbdate")){
            final JSONObject xobj = args.getJSONObject(0);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject obj = DBOperator.chatHistoryQueryDBDate( xobj );
                        if (obj == null ){
                            callbackContext.error("error");
                        }else{
                            callbackContext.success( obj );
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
            return true;
        }


        if (action.equals("getContacts")){
            final JSONObject obj = args.getJSONObject(0);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject contactsSelObj = DBOperator.getContactsUser( obj );
                        if ( contactsSelObj == null ){
                            callbackContext.error("error");
                        }else{
                            callbackContext.success( contactsSelObj);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

            return true;
        }


        //rereaded
        if (action.equals("rereaded")){
            final  JSONObject obj = args.getJSONObject(0);
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        DBOperator.chatHistoryReReaded( obj );
                        Log.d(TAG , "WeChat rereaded");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

            return true;
        }

        //existOwner
        if (action.equals("existOwner")){
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if ( DBOperator.contactsExistOwner() != null ) {
                            callbackContext.success( 1 );
                        }else{
                            callbackContext.success( 0 );
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

            return true;
        }

        //unreadchat
        if (action.equals("unreadchat")){
            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    JSONObject jobj = null;
                    try {
                        jobj = DBOperator.chatLastQuery3();
                        if ( jobj != null){
                            callbackContext.success( jobj);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            });

            return  true;
        }

        if (action.equals("getOnLineUsers")){
            final JSONObject obj = args.getJSONObject(0);
            RestClient.BASE_URL = EBusService.serverURL;
            String xurl = "/onlineusers/mydata?data=" + obj.toString();
            RestClient.get(xurl , null , new JsonHttpResponseHandler(){
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    //super.onSuccess(statusCode, headers, response);
                    Log.d(TAG ,"WeChat getOnlinesUsers got onlines");
                    callbackContext.success( response );
                }
            });

            return true;
        }

        if (action.equals("getOpenRooms")){
            final JSONObject obj = args.getJSONObject(0);

            if ( EBusService.serverURL != null ){
                String from = obj.has("from") ? obj.getString("from") : "";
                if (from.isEmpty()){ from = "togroup"; }

                obj.remove("from");
                obj.put("sid", from );

                //get opneroots user
                if (mNetworkInfo != null && mNetworkInfo.isAvailable()) {
                    RestClient.BASE_URL = EBusService.serverURL;
                    String xurl = "/xopenrooms/" + obj.getString("sid") + "/" + obj.getString("channel");

                    RestClient.get( xurl , null , new JsonHttpResponseHandler(){
                        @Override
                        public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                            //super.onSuccess(statusCode, headers, response);
                            Log.d(TAG , "WeChat getOpenRooms online");
                            try {
                                callbackContext.success( response );

                                //update sqlite
                                DBOperator.openRoomsUpdInsert( response );

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                }else{ //offline
                    Log.d(TAG , "WeChat getOpenRooms offline");
                    //getSqlite
                    cordova.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONObject xobj = DBOperator.getOpenRooms( obj );
                                if ( xobj != null ){
                                    callbackContext.success( xobj );
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                    });

                }
            }
            return true;
        }


        //register contacts
        if (action.equals("register")){
            Log.d(TAG , "WeChat register");
            final JSONObject regParams = args.getJSONObject(0);
            final JSONObject xobj = DBOperator.chkContacts( regParams );

            cordova.getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {

                        if ( xobj == null){
                            callbackContext.error("error");
                            return;
                        }

                        String  contactsAction = regParams.getString("action");
                        Log.d(TAG ,  xobj.toString() );
                        boolean isgroup =  (xobj.getInt("isgroup") == 1) ? true : false ;

                        //insert
                        if (contactsAction.equals("insert")){
                            if ( isgroup && EBusService.mSocket != null ){
                                JSONObject obj = new JSONObject();
                                obj.put("channel" , xobj.getString("m_id"));
                                sendSubscribe( obj , true );

                            }

                            if ( ! DBOperator.contactsIns( xobj ) ){
                                callbackContext.error("error");
                            }

                            //update
                        }else if (contactsAction.equals("update")){
                            if ( isgroup && EBusService.mSocket != null ){
                                JSONObject obj = new JSONObject();
                                obj.put("channel" , xobj.getString("m_id"));
                                sendSubscribe( obj , true );
                            }

                            if ( ! DBOperator.contactsUpd( xobj ) ){
                                callbackContext.error("error");
                            }

                            //delete
                        }else if (contactsAction.equals("delete")) {
                            if (isgroup && EBusService.mSocket != null) {
                                JSONObject obj = new JSONObject();
                                obj.put("channel", xobj.getString("m_id"));
                                sendSubscribe(obj, false);
                            }

                            if (!DBOperator.contactsDel(xobj)) {
                                callbackContext.error("error");
                            }

                            //delallExcOwner || delcorps
                        }else if ( contactsAction.equals("delallExcOwner") || contactsAction.equals("delcorps") ) {
                            if (!DBOperator.contactsDel(xobj)) {
                                callbackContext.error("error");
                            }
                        }

                        //reset ContactsHashObj
                        DBOperator.ContactsHashObj = null ;

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });

            return true;
        }


        return false;
    }


    //start BorodcastReceiver
    private void startReceiver(){
        IntentFilter intentFilter = new IntentFilter( filterAction );
        if (this.receiver == null){
            this.receiver = new BroadcastReceiver() {
                @Override
                public void onReceive(Context context, Intent intent) {
                    //Log.d(TAG, "Got receiver");
                    //final Bundle bundle = intent.getExtras();
                }
            };
            //register listener
            webView.getContext().registerReceiver(this.receiver , intentFilter);
        }
    }


    //recieve data
    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessage(WBundle event) throws JSONException {
        Log.d(TAG , "WeChat MainThread Got reciever");

        String action =  event.action ;
        final JSONObject pack = event.pack ;
        if ( myCallbackContext != null && pack != null ){
            //mqmsg
            if ( action.equals("mqmsg")){
                Log.d( TAG , "WeChat action mqmsg recieve");
                cordova.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        PluginResult result = new PluginResult(PluginResult.Status.OK,  pack );
                        result.setKeepCallback(true);
                        myCallbackContext.sendPluginResult(result);
                    }
                });
            }

            //invite
            if (action.equals("invite")) {
                Log.d(TAG, "WeChat action invite recieve wechatOnInviteRecivedInterface");
                cordova.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        WeChat.this.webView.loadUrl("javascript: wechatOnInviteRecivedInterface("+ pack + ")");
                    }
                });
            }


            //unreadchat
            if (action.equals("unreadchat")) {
                Log.d(TAG, "WeChat action unreadchat recieve wechatOnUnReadChatInterface");
                cordova.getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        WeChat.this.webView.loadUrl("javascript: wechatOnUnReadChatInterface("+ pack + ")");
                    }
                });
            }

            //unreadchattask
            if (action.equals("unreadchattask")) {
                Log.d(TAG, "WeChat action unreadchattask recieve wechatOnUnReadChatInitInterface");
                if (checkSyncTsInit){
                    cordova.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.d(TAG , "WeChat task finish to get DBOperator.chatLastQuery3");
                            WeChat.this.webView.loadUrl("javascript: wechatOnUnReadChatInitInterface("+ pack + ")");
                        }
                    });
                }

            }


            //socket
            if (action.equals("socket")) {
                Log.d(TAG, "WeChat action socket recieve wechatOnConnectErrorInterface");

                cordova.getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(2000);
                                if ( EBusService.mSocket !=null && EBusService.mSocket.connected()) return;

                                WeChat.this.webView.loadUrl("javascript: wechatOnConnectErrorInterface("+ pack + ")");
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                });
            }

        }
    }


    private void SetInitConn() throws JSONException {
        Log.d(TAG , "WeChat initConn");
        JSONObject obj = getChatSettingsSharePre();
        if ( obj != null ){
            EBundle eb = new EBundle();
            eb.action = EBusService.INIT;
            eb.settings = obj ;
            sendService( context , eb);
        }
    }

    public void saveChatSettingsSharePre(JSONObject obj){
        //save Environment
        SharedPreferences.Editor editor = cordova.getActivity().getSharedPreferences(SPSetting , Context.MODE_PRIVATE).edit();
        editor.putString(SPSettingkey , obj.toString());
        editor.commit();
        EBusService.mSettings = null ;
    }


    public JSONObject getChatSettingsSharePre() throws JSONException {
        SharedPreferences pre = context.getSharedPreferences( EBusService.SPSetting, Context.MODE_PRIVATE);
        String conf = pre.getString( EBusService.SPSettingkey , "");
        if (conf.isEmpty()) {
            Log.d(TAG , "WeCaht getChatSettingsSharePre conf.isEmpty");
            return null;
        }else{
            JSONObject obj = new JSONObject(conf);
            return obj ;
        }
    }

    //stop BorodcastReceiver
    private void stopReceiver(){
        if (this.receiver != null){
            try{
                webView.getContext().unregisterReceiver(this.receiver);
                this.receiver = null ;
            }catch (Exception e){
                Log.d(TAG , "Error stopReceiver");
            }
        }
    }


    private void sendSubscribe(JSONObject obj ,boolean isSub){
        EBundle eb = new EBundle();
        eb.action =  (isSub) ?  EBusService.SUBSCRIBE: EBusService.UNSUBSCRIBE ;
        eb.pack = obj;
        sendService( context, eb );
    }

    private void sendMultiSubscribe(JSONObject obj, boolean isSub){
        EBundle eb = new EBundle();
        eb.action = (isSub) ? EBusService.MULTISUBSCRIBE : EBusService.MULTIUNSUBSCRIBE ;
        eb.pack = obj;
        sendService( context, eb );
    }

    private void initNetworkInfo() {

        ConnectivityManager mConnectivityManager = (ConnectivityManager)cordova.getActivity().getSystemService(Context.CONNECTIVITY_SERVICE);
        mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
    }


    //start service
    public void sendService(Activity context){
        if ( ! EBusService.isActive() ){
            Intent intent = new Intent( context , EBusService.class);
            context.startService( intent );
        }
    }

    //send EBundle
    public void sendService(final Activity context , final EBundle eb){
        if (EBusService.isActive()){
            EventBus.getDefault().post(eb);
            Log.d(TAG , "sendService EBusService is live");
        }else{
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent intent = new Intent( context , EBusService.class);
                        context.startService( intent );
                        Thread.sleep( 3000 );
                        EventBus.getDefault().post(eb);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
            Log.d(TAG , "sendService EBusService is dead");
        }
    }


    public void sendStartService(){
        Intent intent = new Intent(context, EBusService.class );
        context.startService( intent );
    }

    public void sendStopService(){
        EBundle eb = new EBundle();
        eb.action =  EBusService.STOPSERVICE;
        sendService( context , eb );
    }

    public String getDeviceID(){
        try {
            return Settings.Secure.getString( context.getContentResolver(), Settings.Secure.ANDROID_ID);
        }catch (Exception e){
            return  "nulldeviceid";
        }
    }


    @Override
    public void onPause(boolean multitasking) {
        super.onPause(multitasking);
        activeInstance = 0;
    }

    @Override
    public void onResume(boolean multitasking) {
        super.onResume(multitasking);
        activeInstance++;
    }

    @Override
    public void onDestroy() {
        Log.d(TAG,"WeChat onDestroy");
        stopReceiver();
        activeInstance = 0;
        EventBus.getDefault().unregister(this);
        super.onDestroy();
    }
}
