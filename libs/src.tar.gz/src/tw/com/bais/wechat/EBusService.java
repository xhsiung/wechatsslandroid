package tw.com.bais.wechat;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.os.PowerManager;
import android.provider.Settings;

import android.support.v7.app.NotificationCompat;

import android.util.Log;

import com.loopj.android.http.JsonHttpResponseHandler;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import cz.msebera.android.httpclient.Header;
import cz.msebera.android.httpclient.entity.mime.content.StringBody;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import me.leolin.shortcutbadger.ShortcutBadger;
import okhttp3.OkHttpClient;

public class EBusService extends Service {
    public static final String TAG = "WeChat2";
    public static final int INIT = 0x00;
    public static final int CLEAR = 0x01;
    public static final int CONNECT = 0x02;
    public static final int DISCONNECT = 0x03;
    public static final int RECONNECT = 0x04;
    public static final int SUBSCRIBE = 0x05;
    public static final int UNSUBSCRIBE = 0x06;
    public static final int SEND = 0x07;
    public static final int LOOPBACK = 0x08;
    public static final int UPDATEDB = 0x09;
    public static final int SECRETINVITE = 0x0A;
    public static final int NOTIFYSEND = 0x0B;
    public static final int OPENROOMS = 0x0C;
    public static final int STOPSERVICE = 0x0D;
    public static final int MULTISUBSCRIBE = 0x0E;
    public static final int MULTIUNSUBSCRIBE = 0x0F;

    public static final String SPSetting = "SPSETTING";
    public static final String SPSettingkey = "wechatSetting";
    public static Socket mSocket = null ;
    public static int TaskCount = 0;

    public static JSONObject mSettings = null ;
    public static int activeInstance = 0 ;
    public static int unreadnum = 0 ;
    public static String serverURL = "" ;

    public static String SID = "";
    public static String CUSTOMNAME = "";
    public static String ADDRESSBOOK = "";
    public static String CID = "";
    public static HashSet<String> channSet = null ;

    public static int ReConnCount = 0 ;
    public int ConnectErrorTimes = 0 ;
    public int greaterConnectErrorTimes = 6;

    public OkHttpClient okHttpClient = null;
    public NetworkInfo mNetworkInfo = null;
    public int OpenRoomsCount = 0 ;
    public String authorityCP = "wechatcp.bais.com.tw";
    public String filterAction = "tw.com.bais.wechat.WeChat";
    public PowerManager.WakeLock wakeLock = null;


    public DBOperator dbOperator = null ;
    public NotificationManager notificationManager= null;

    public String lastcid = "";
    public String sendLastChann="";
    public int sendLastChannTimes=0;

    public static boolean  isActive(){
        return (activeInstance > 0 );
    }

    public EBusService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        channSet = new HashSet<String>();
        HttpsUtils httpsutils = new HttpsUtils();
        okHttpClient = httpsutils.getTrustAllClient();

        activeInstance++;
        initNetworkInfo();

        if (DBOperator.mDB == null){
            dbOperator = new DBOperator(this);
        }

        EventBus.getDefault().register(this);
        Log.d(TAG , "EBusService start onCreate");
    }

    private void ClearVariable(){
        mSocket = null ;
        activeInstance = 0 ;
        unreadnum = 0 ;
        //serverURL = "" ;
        TaskCount = 0;
        SID = "";
        ConnectErrorTimes = 0 ;
        ReConnCount = 0 ;
        //CUSTOMNAME = "";
        //ADDRESSBOOK = "";
        //CID = "";
        channSet = null ;
        Log.d(TAG, "EBusService ClearVariable");
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    public void onMessage(EBundle eb) throws JSONException, ClassNotFoundException, UnsupportedEncodingException {

        //detact network
//        if (mNetworkInfo == null || !mNetworkInfo.isAvailable() ) {
//            Log.d(TAG , "EBusService execute mNetworkInfo error");
//            return;
//        }

        Log.d(TAG, "EBusService ThreadMode.MAIN");
        switch (eb.action){
            case INIT:
                Init( eb.settings );
                break;
            case CONNECT:
                Connect();
                break;
            case RECONNECT:
                break;
            case DISCONNECT:
                DisConnect();
                break;
            case SUBSCRIBE:
                Subscribe( eb.pack );
                break;
            case UNSUBSCRIBE:
                UnSubcribe( eb.pack );
                break;
            case SEND:
                Send( eb.pack );
                break;
            case LOOPBACK:
                SendLoopBack(eb.pack);
                break;
            case SECRETINVITE:
                  SecretInvite(eb.pack);
                break;
            case NOTIFYSEND:
                NotifySend( eb.pack );
                break;
            case OPENROOMS:
                OpenRooms( eb.pack );
                break;
            case STOPSERVICE:
                stopSelf();
                break;
            case MULTISUBSCRIBE:
                MultiSubScribe( eb.pack );
                break;
            case MULTIUNSUBSCRIBE:
                MultiUnSubscribe( eb.pack );
                break;
        }
    }


    private void Init(JSONObject obj) throws JSONException, UnsupportedEncodingException {
        mSettings = obj ;

        if (Connect()){
            //Subscribe();
            MultiSubScribe();
            SyncData();
            SendSignal();
            SetOpenRooms();
            ConnectErrorTimes = 0 ;
        }else{
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep( 1500 );
                        //Subscribe();
                        MultiSubScribe();
                        SyncData();
                        SendSignal();
                        SetOpenRooms();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }

        SyncRestContactsOnwer();
        SaveEl();
        Log.d(TAG , "EBusService Init");
    }

    //check openrooms status
    public void SetOpenRooms() throws JSONException {
         if (WeChat.isActive()){
             OpenRoomsCount = 0;
             Log.d(TAG , "OpenRoomsCount = 0");
         }else{
             if ( OpenRoomsCount < 1) {
                 JSONObject root = new JSONObject();
                 root.put("action", "blur");
                 OpenRooms(root);
             }
             OpenRoomsCount++;
         }
    }

    public void SaveEl() throws JSONException {
        if ( mSettings.getInt("hasSaveEl") == 1 ){
            releaseWakeLock();
        }else{
            acquireWakeLock();
        }
    }


    public String getInviteChann(String sid , String tid) throws JSONException {
        if ( sid.compareTo( tid ) == 0 ) return sid + "@" + tid;
        String max = sid.compareTo( tid ) > 0 ? sid : tid;
        String min = sid.compareTo( tid ) < 0 ? sid : tid;
        return max + "@" + min;
    }

    public HashSet<String> getInviteChann2(JSONObject obj) throws JSONException {
        JSONArray jarr = obj.getJSONArray("data");
        HashSet<String> arr = new HashSet<String>();
        for (int i=0; i < jarr.length() ; i++){
            String sid = jarr.getJSONObject(i).getString("sid");
            String tid = jarr.getJSONObject(i).getString("tid");
            String gid = jarr.getJSONObject(i).getString("gid");

            String newchann="";
            if (gid.isEmpty()){
                newchann = getInviteChann( sid , tid );
            }else{
                newchann =  gid ;
            }
            arr.add( newchann );
        }
        return arr;
    }


    private void QueryUnreadDBSend(String action, JSONObject root ) throws JSONException {

        //show unread records
        if (root.getJSONArray("data").length() == 0 ) return;
        sendEBusData( action , root );
        Log.d(TAG , "EBusService QueryUnreadDBSend:" + action );

        //send unreadchat
        QueryUnreadDBTaskSend("unreadchat" , root );

        Log.d(TAG , "EBusService QueryUnreadDBSend:unreadchat");
    }


    private JSONObject QueryUnreadDB( String action,int offset,int limit ) throws JSONException {
        //return  DBOperator.chatHistoryQueryUnread2(offset,limit) ;
        JSONObject root = (DBOperator.UnReadChatHistoryObj == null) ? DBOperator.chatHistoryQueryUnread2(offset,limit): DBOperator.UnReadChatHistoryObj ;
        return root ;
    }

//
    private JSONObject QueryUnreadDBTaskSend(String action , JSONObject root ) throws JSONException {
       //JSONObject root = (DBOperator.UnReadChatHistoryObj == null) ? DBOperator.chatHistoryQueryUnread2(0,100): DBOperator.UnReadChatHistoryObj ;
        //get chatUnread including  chat_history , chat_contacts tables
        JSONObject root2 = DBOperator.getUnreadRecordFilter( root );
        if (root2.getJSONArray("data").length() == 0 ) return null ;

        sendEBusData( action  , root2 );
        Log.d(TAG , "EBusService QueryUnreadDBTaskSend: "+ action);
        return null;
    }


    private JSONObject QueryUnReadChat(String action) throws JSONException {
        JSONObject root = DBOperator.chatLastQuery3();
        if (root.getJSONArray("data").length() == 0 ) return null ;
        sendEBusData( action , root );
        return root;
    }

    private void sendEBusData( String action , JSONObject obj){
        WBundle wb = new WBundle();
        wb.action = action ;
        wb.pack = obj ;
        EventBus.getDefault().post( wb );
        Log.d(TAG , "EBusService sendEBusData "+ action );
    }

    private  void sendLocalBusData( int action , JSONObject  obj){
        EBundle eb = new EBundle();
        eb.action = action ;
        eb.pack = obj ;
        EventBus.getDefault().post( eb );
    }

    private void sendPureBroadcast( String action , JSONObject  obj) throws JSONException {
        Intent intent = new Intent();
        intent.putExtra("action",  action );
        intent.putExtra("data", obj.toString() );
        intent.setAction(filterAction);
        sendBroadcast( intent );
        Log.d(TAG ,"sendPureBroadcast " + obj.toString() );
    }


    public void MultiSubScribe() throws JSONException {
        String sid = getSID();
        JSONObject obj = DBOperator.getContactsData();

        if (sid.isEmpty() || obj == null) return;

        if (obj != null){
            JSONObject root = new JSONObject();
            JSONArray jarr = obj.getJSONArray("data");
            JSONArray parr = new JSONArray();
            for (int i =0 ; i < jarr.length() ; i++){
                JSONObject row = new JSONObject();
                Integer isgroup = jarr.getJSONObject(i).getInt("isgroup");
                String m_id = jarr.getJSONObject(i).getString("m_id");
                String xchann = "" ;

                //group
                if (isgroup == 1 || m_id.equals(sid)){
                    xchann = m_id ;
                //person
                }else {
                    xchann = getInviteChann( sid , m_id );
                }
                row.put("channel", xchann );
                row.put("device", "mobile");
                parr.put( row );
            }

            //add self channel sid@sid
            JSONObject channObj = new JSONObject();
            channObj.put("channel" , getInviteChann( sid , sid ) );
            channObj.put("device" , "mobile" );
            parr.put( channObj);

            root.put("multichanns", parr );
            MultiSubScribe( root );
        }
    }

    public void Subscribe() throws JSONException {
            String sid = getSID();

            if (sid.isEmpty()) return;
            //add group channel
            JSONObject obj = DBOperator.getContactsGroup();
            if (obj != null && obj.getInt("length") != 0) {
                JSONArray jarr = obj.getJSONArray("data");
                for (int i = 0; i < jarr.length(); i++) {
                    JSONObject root = new JSONObject();
                    String m_id = jarr.getJSONObject(i).getString("m_id");
                    root.put("channel", m_id);
                    NoRepeatSubscribe(root);
                }
            }

            //add self channel
            JSONObject root2 = new JSONObject();
            root2.put("channel", sid);
            root2.put("key", mSettings.getString("key"));
            NoRepeatSubscribe(root2);
    }

    //enter
    public void Subscribe(JSONObject jobj) throws JSONException {
        if (mSocket != null && mSocket.connected()){
            String channel = jobj.getString("channel") ;
            jobj.remove("device");
            jobj.put("device", "mobile" );

            mSocket.emit("subscribe" , jobj.toString() );
            channSet.add( channel ) ;
            Log.d(TAG , "Subscribe " + jobj.toString());
        }
    }

    //enter
    public void NoRepeatSubscribe(JSONObject jobj) throws JSONException {
        if (mSocket != null && mSocket.connected()){
            String channel = jobj.getString("channel") ;
            jobj.remove("device");
            jobj.put("device", "mobile" );

            if ( channSet.contains( channel )){
                Log.d(TAG , "NoRepeatSubscribe channel included:"+ channel);
            }else{
                mSocket.emit("subscribe" , jobj.toString() );
                channSet.add( channel ) ;
                Log.d(TAG , "NoRepeatSubscribe " + jobj.toString());
            }
        }
    }


    private void MultiSubScribe(JSONObject pack) throws JSONException {
        if ( mSocket != null && mSocket.connected()){

            mSocket.emit("multisubscribe", pack.toString() );
            JSONArray jarr = pack.getJSONArray("multichanns");
            for (int i=0 ; i < jarr.length() ; i++){
                String channel = jarr.getJSONObject(i).getString("channel");
                channSet.add( channel ) ;
            }
        }
    }

    private void MultiUnSubscribe(JSONObject pack) throws JSONException {
        if ( mSocket != null && mSocket.connected()){
            mSocket.emit("multiunsubscribe", pack.toString());

            JSONArray jarr = pack.getJSONArray("multichanns");
            for (int i=0 ; i < jarr.length() ; i++){
                String channel = jarr.getJSONObject(i).getString("channel");
                channSet.remove( channel ) ;
            }
        }
    }


    public void UnSubcribe(JSONObject jobj) throws JSONException {
        if (mSocket != null && mSocket.connected()){
            Log.d(TAG , "UnSubscribe " + jobj.toString());
            mSocket.emit("unsubscribe" , jobj.toString());
            channSet.remove( jobj.getString("channel"))  ;
        }
    }

    public static void UnSubcribeAll() throws JSONException {
        if (mSocket != null && mSocket.connected()){
            JSONObject jobj = new JSONObject();
            Iterator<String> it = channSet.iterator();
            while (it.hasNext()){
                jobj.put("channel" , it.next() );
                mSocket.emit("unsubscribe" , jobj.toString());
                jobj.remove("channel");
            }
            channSet.clear();
            Log.d(TAG , "UnSubscribeAll ");
        }
    }


    //for user Send
    public void Send(JSONObject jobj) throws JSONException {
            String channel = jobj.has("channel") ? jobj.getString("channel") : "" ;
            String gid = jobj.has("gid") ? jobj.getString("gid"): "";
            String cid = getCID();
            JSONObject xjobj = jobj.has("cid") ? jobj : jobj.put("cid", cid);

            if (!channel.equals(sendLastChann) && gid.isEmpty()){
                sendLastChannTimes = 0 ;
                SecretInvite( jobj );
                DelaySend( xjobj ,300 );
            }else if(channel.equals(sendLastChann) && gid.isEmpty() && sendLastChannTimes < 3){
                sendLastChannTimes ++ ;
                SecretInvite( jobj );
                DelaySend( xjobj ,300 );
            }else{
                DelaySend( xjobj , 0 );
            }
            sendLastChann = channel;
    }

    public void DelaySend(final JSONObject jobj, final int delay) throws JSONException {
        if (mSocket != null && mSocket.connected()) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep( delay );
                        mSocket.emit("send",  jobj.toString());
                        Log.d(TAG , "DelaySend "+ delay + "," + jobj.toString());
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }).start();
        }
    }

    public void SyncUnRead( JSONObject jobj) throws JSONException {
        if (mSocket != null && mSocket.connected()){
            if (getSID().isEmpty() ) return;

            jobj.put("sid" , getSID() );
            Log.d(TAG ,"EBusService SynUnRead emit->"+jobj.toString());

            mSocket.emit("unread" , jobj.toString() );
        }
    }

    public void OpenRooms( JSONObject jobj ) throws JSONException {

        if (mSocket != null && mSocket.connected()){
            if ( ! jobj.has("channel") ) return;
            String channel =  jobj.getString("channel");
            String sid = getSID();
            jobj.put("sid", sid );
            mSocket.emit("openrooms" , jobj.toString() );

            //add readed
            DBOperator.chatHistoryReReaded( channel );
            //read  unreadcount
            int unreadnum = DBOperator.getChatHistoryUnReadCount();
            ShortcutBadger.with( getApplicationContext() ).count( unreadnum);
            Log.d(TAG , "EBusService OpenRooms unread -->" +  unreadnum );
            Log.d(TAG , "EBusService OpenRooms -->" +  jobj.toString());
        }
    }

    public void SecretInvite( JSONObject jobj ) throws JSONException {
        if (mSocket != null && mSocket.connected()){
            String sid = jobj.has("sid") ? jobj.getString("sid"): "";
            String tid = jobj.has("tid") ? jobj.getString("tid"): "";
            String gid = jobj.has("gid") ? jobj.getString("gid"): "";

            JSONObject askData = new JSONObject();
            askData.put("action", "invite");
            askData.put("sid", sid );
            askData.put("tid", tid );
            askData.put("gid", gid );

            if (gid.isEmpty()){
                askData.put("channel", tid );
            }else{
                askData.put("channel", gid );
            }

            Log.d(TAG , "SecretInvite " + askData.toString());
            mSocket.emit("ask",  askData.toString());
        }
    }

    //loopback
    public void SendLoopBack(JSONObject jobj) throws JSONException {
        if (mSocket != null && mSocket.connected()){
            Log.d(TAG , "SendLoopBack" + jobj.toString());
            mSocket.emit("loopback" , jobj.toString());
        }
    }

    //put clent to server
    public void SendSignal() throws JSONException {
        if (mSocket != null && mSocket.connected()){
            JSONObject jobj = new JSONObject() ;
            jobj.put("sid", getSID() );
            jobj.put("name", CUSTOMNAME );
            jobj.put("addressbook", ADDRESSBOOK );
            jobj.put("wechat", WeChat.isActive());
            mSocket.emit("signal", jobj.toString());
        }
    }

    private boolean Connect() throws JSONException {
        Log.d(TAG , "EBusService Connect");
        mSettings = getMSettings();

        if ( mSettings !=null && mSocket == null){
            try {
                String protocol = mSettings.getString("protocol");
                if ( protocol.equals("http") ){
                    serverURL =  protocol + "://" + mSettings.getString("serverip") + ":" + mSettings.getString("port");
                    mSocket = IO.socket( serverURL );

                }else{
                    IO.setDefaultOkHttpWebSocketFactory(okHttpClient);
                    IO.setDefaultOkHttpCallFactory(okHttpClient);
                    IO.Options opts = new IO.Options();
                    opts.callFactory = okHttpClient;
                    opts.webSocketFactory = okHttpClient;
                    serverURL = protocol + "://" + mSettings.getString("serverip");
                    mSocket = IO.socket( serverURL , opts );
                }

            } catch (URISyntaxException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        Log.d(TAG , serverURL );

        if ( !mSocket.connected() ){
            mSocket.once(Socket.EVENT_CONNECT_ERROR, onConnectError);
            mSocket.once(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
            mSocket.once(Socket.EVENT_ERROR, onConnectError);
            mSocket.on(Socket.EVENT_RECONNECT, onReconnect);
            mSocket.on("mqmsg" , OnMqMsg );
            mSocket.on("unreaded" , OnUnReaded );
            mSocket.on("asked",OnAsked);
            mSocket.on("openroomsed" , OnOpenRoomsed) ;
            mSocket.on("signaled" , OnSignaled);
            mSocket.on("sessioned" , OnSessioned);
            mSocket.on("systemed" , OnSystemed );
            mSocket.connect();
            return  false ;
        }else{
            return true;
        }
    }

    private void DisConnect(){
        if (mSocket !=null && mSocket.connected()){
            mSocket.off(Socket.EVENT_CONNECT_ERROR, onConnectError);
            mSocket.off(Socket.EVENT_CONNECT_TIMEOUT, onConnectError);
            mSocket.off(Socket.EVENT_ERROR, onConnectError);
            mSocket.off(Socket.EVENT_RECONNECT, onReconnect);
            mSocket.off("mqmsg",OnMqMsg );
            mSocket.off("unreaded" , OnUnReaded );
            mSocket.off("asked",OnAsked);

            mSocket.off("signaled" , OnSignaled);
            mSocket.off("sessioned" , OnSessioned);
            mSocket.off("systemed" , OnSystemed );
            mSocket.off("openroomsed" , OnOpenRoomsed );
            mSocket.disconnect();
            mSocket.close();
            mSocket = null;
        }
        channSet.clear();

        Log.d(TAG , "EBusService disconect");
    }


    private JSONObject getMSettings() throws JSONException {
        if (mSettings == null ){
            SharedPreferences pre = EBusService.this.getSharedPreferences(SPSetting, Context.MODE_PRIVATE);
            String conf = pre.getString(SPSettingkey, "");
            if (conf.isEmpty()) {
                Log.d(TAG , "EBusService conf.isEmpty()");
                return null;
            }
            mSettings = new JSONObject(conf);
        }
        return mSettings ;
    }

    //notfication
    private void NotifySend(JSONObject pack) throws JSONException, ClassNotFoundException, UnsupportedEncodingException {

        mSettings = getMSettings() ;
        if (mSettings == null ) {
            Log.d(TAG , "EBusService NotifySend mSettings none");
            return;
        }
        int hasNotify = mSettings.getInt("hasNotify");
        if (hasNotify == 0 ) {
            Log.d(TAG , "EBusServie NotifySend disable");
            return;
        }

        String target = mSettings.getString("notifyTarget");
        Intent intent = new Intent( EBusService.this , Class.forName(target));

        PendingIntent pIntent = PendingIntent.getActivity(EBusService.this, 0, intent, 0);
        NotificationCompat.Builder mBuilder = (NotificationCompat.Builder) new NotificationCompat.Builder(EBusService.this).setSmallIcon(getResources().getIdentifier("icon", "mipmap", getPackageName()));

        mBuilder.setAutoCancel(true);

        int defaults = 0;
        Log.d(TAG , "NotifySend:" + mSettings.toString() );
        if ( mSettings.getInt("hasSound") == 1){
            Log.d(TAG , "hasSound 1");

            defaults = defaults | Notification.DEFAULT_SOUND;
        }

        if ( mSettings.getInt("hasVibrate") == 1){
            Log.d(TAG , "hasVibrate 1");
            defaults = defaults | Notification.DEFAULT_VIBRATE;
//            long[] vibtimes = {0 ,100 ,200 ,300};
//            mBuilder.setVibrate(vibtimes);
        }
        mBuilder.setDefaults(defaults);

        //array
        String action = pack.getString("action");

        JSONArray jarr = pack.getJSONArray("data");
        String xtitle = mSettings.getString("notifyTitle");
        String xcontent = mSettings.getString("notifyTicker");

        if (action.equals("send")) {
            String who = pack.getString("who");
            String xid = who.equals("reciver") ? pack.getString("sid") : pack.getString("tid") ;

            for (int i=0 ; i < jarr.length(); i++) {

                if (xtitle.isEmpty() && xcontent.isEmpty() ){
                    String data = jarr.getJSONObject(i).getString("data");

                    JSONObject jobj  = DBOperator.getContactsData( xid );
                    xtitle = (jobj == null) ? "系統公告:" : (jobj.getString("custom_name") + ":");

                    if (data.startsWith("image/png;base64")||data.startsWith("data:image")  ){
                        xcontent = "圖片訊息!";
                    }else if (data.startsWith("donwoladfile:")){
                        xcontent = "檔案訊息!";
                    }else{
                        xcontent = URLDecoder.decode(data , "UTF-8");
                    }
                }

                mBuilder.setContentTitle( xtitle );
                mBuilder.setContentText( xcontent );

                mBuilder.setContentIntent(pIntent);
                notificationManager =(NotificationManager) getSystemService(NOTIFICATION_SERVICE);

                notificationManager.notify(0, mBuilder.build());

                //only notify send a record ******************************************************
                break;
            }
        }


        if (action.equals("notify")) {
            for (int i=0 ; i < jarr.length(); i++) {
                String data = jarr.getJSONObject(i).getString("data") ;

                if (data.indexOf("@") == -1 ) {
                    Log.d(TAG , "EBusService NotifySend has no @");
                    continue;
                }
                String[] whoSay = data.split("@",2);

                mBuilder.setContentTitle( whoSay[0] );
                mBuilder.setContentText( whoSay[1] );
                mBuilder.setContentIntent(pIntent);
                notificationManager =(NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                notificationManager.notify(0, mBuilder.build());
                //only notify send a record ******************************************************
            }

        }

        Log.d(TAG , "EBusService NotifySend");
    }



    public static String getCID(){
        String sid = getSID();
        CID = sid + System.currentTimeMillis();
        return CID ;
    }


    public static String getSID(){
        if (SID.isEmpty()){
            try {
                JSONObject jobj = DBOperator.getContactsOwnerMid();
                if (jobj == null ) return "";
                SID =  jobj.has("m_id") ? jobj.getString("m_id"): "";
                CUSTOMNAME = jobj.has("custom_name") ?  jobj.getString("custom_name") : "";
                ADDRESSBOOK = jobj.has("addressbook") ? jobj.getString("addressbook"): "";
                if (SID.isEmpty()) return  "";

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return SID;
    }


    private void SyncRestContactsOnwer() throws JSONException, UnsupportedEncodingException {
        RestClient.BASE_URL = serverURL ;

        final  JSONObject owner = DBOperator.contactsExistOwner();
        if ( owner == null ) return;

        //String ulast_updated_time = owner.getString("ulast_updated_time");
        //if ( !ulast_updated_time.isEmpty() ) return;
        //DBOperator.getContactsGroup()

        JSONObject obj  = DBOperator.getContactsGroup();
        ArrayList<String> xgroup = new ArrayList<String>();

        if (obj != null){
            JSONArray jarr = obj.getJSONArray("data");
            for (int i=0; i < jarr.length() ; i++){
                xgroup.add( jarr.getJSONObject(i).getString("m_id") );
            }
        }

        String mygroup = android.text.TextUtils.join(",",xgroup) ;
        owner.put("xgroup", mygroup );
        owner.put("unread",0);
        owner.put("platform","android");
        owner.put("token","1234567890");

        try {
            RestClient.post(getBaseContext(), "/contacts/add" , owner , new JsonHttpResponseHandler(){
                @Override
                public void onSuccess(int statusCode, Header[] headers, JSONObject response) {
                    //super.onSuccess(statusCode, headers, response);
                    try {
                        DBOperator.contactsUpd( response );
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                    Log.d(TAG , "WeChat addCloudAccount success");
                }
            });

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    //Unread Get Rows
    public void SyncData() throws JSONException {
        RestClient.BASE_URL = serverURL ;
        JSONObject obj = DBOperator.SyncChatTS();
        SyncUnRead( obj );
    }


    //Sender
    private void SenderTask(JSONObject root ) throws JSONException {
        Log.d(TAG, "EBusService Enter SenderTask");

        if (root.has("action") && root.getString("action").equals("send")) {
            Log.d(TAG , root.toString() );
            //sqlite readed
            DBOperator.chatHistoryUpdInsert(root);
            //refresh syncts table
            DBOperator.refSyncts();

            JSONObject xroot = QueryUnreadDB("send",0,100);
            int unread = xroot.getInt("length");
            ShortcutBadger.with( getApplicationContext() ).count( unread );
            Log.d( TAG  , "EBusService SenderTask unread:" + unread );

            if (WeChat.isActive()){
                Log.d(TAG , "SenderTask WeChat.isActive");
                QueryUnreadDBSend("mqmsg",xroot);
            }
            Log.d(TAG, "EBusService SenderTask action:send ");
        }

    }


    //Reciver
    private void ReciverTask(JSONObject root ) throws JSONException {
        Log.d(TAG, "EBusService Enter ReciverTask");
        Log.d(TAG , root.toString() );

        if (root.has("action") && root.getString("action").equals("send")) {
            Log.d(TAG , "OnMqMsg send " + root.toString());
            //update insert sqlite
            DBOperator.chatHistoryUpdInsert( root );
            //refresh syncts table
            DBOperator.refSyncts();

            JSONObject xroot = QueryUnreadDB("send",0,100);
            int unread = xroot.getInt("length");
            ShortcutBadger.with( getApplicationContext() ).count( unread);
            Log.d( TAG  , "EBusService ReciverTask unread:" + unread );

            if (WeChat.isActive()){
                QueryUnreadDBSend("mqmsg",xroot);
            }else{
                //Notfication
                EBundle eb = new EBundle();
                eb.action = EBusService.NOTIFYSEND;
                eb.pack = root ;
                EventBus.getDefault().post( eb );
            }

            Log.d(TAG, "EBusService onMqMsg ReciverTask action send mobile ");
        }


        //invite and reciver
        if ( root.has("action") && root.getString("action").equals("invite") ) {
            //update insert sqlite , true:readed
            DBOperator.chatHistoryUpdInsert( root , true );
            //refresh syncts table
            DBOperator.refSyncts();

            if (WeChat.isActive()){
                sendEBusData( "invite" , root);
            }

            Log.d(TAG , "EBusService onMqMsg action invite mobile");
        }


         //NOTIFYSEND
        if (root.has("action") && root.getString("action").equals("notify") ) {
            //update insert sqlite
            DBOperator.chatHistoryUpdInsert( root , true );
            //refresh syncts table
            DBOperator.refSyncts();

            //do something here
            EBundle eb = new EBundle();
            eb.action = EBusService.NOTIFYSEND;
            eb.pack = root ;
            EventBus.getDefault().post( eb );

            Log.d(TAG, "EBusService onMqMsg ReciverTask action notify mobile");
        }

    }


    private void SenderRecieveTask( JSONObject root ) throws JSONException {
        Log.d(TAG, "EBusService Enter SenderRecieveTask");
        //update insert sqlite

        if (root.getString("action").equals("notify")){
            DBOperator.chatHistoryUpdInsert( root , true );
        }else{
            DBOperator.chatHistoryUpdInsert( root );
        }
        //refresh syncts table
        DBOperator.refSyncts();

        if (root.has("action") && root.getString("action").equals("send")) {
            Log.d(TAG , "EBusService SenderRecieveTask " + root.toString());

            JSONObject xroot = QueryUnreadDB("send",0,100);
            int unread = xroot.getInt("length");
            ShortcutBadger.with( getApplicationContext() ).count( unread);
            Log.d( TAG  , "EBusService unread:" + unread);

            if (WeChat.isActive()){
                QueryUnreadDBSend("mqmsg",xroot);
            }
        }

        //invite and reciver
        if ( root.has("action") && root.getString("action").equals("invite") ) {
            //sender
            if (root.getString("who").equals("sender")) return;

            sendEBusData( "invite" , root);
            Log.d(TAG , "EBusService onMqMsg action invite mobile");
        }


        //NOTIFYSEND
        if (root.has("action") && root.getString("action").equals("notify") ) {
            //sender
            if (root.getString("who").equals("sender")) return;

            //do something here
            EBundle eb = new EBundle();
            eb.action = EBusService.NOTIFYSEND;
            eb.pack = root ;
            EventBus.getDefault().post( eb );
            Log.d(TAG, "EBusService onMqMsg ReciverTask action notify mobile");
        }
    }

    private Emitter.Listener OnMqMsg = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG, "EBusService OnMqMsg");
            try {
                if (args[0] == null ) return ;
                JSONObject obj = new JSONObject(args[0].toString());

                //check the same pack
                String cid = obj.getString("cid");
                String device = obj.getString("device");
                if ( cid.equals( lastcid ) || !device.contains("mobile")) {
                    Log.d(TAG , "EBusService onMqMsg the same cid or not mobile device return");
                    return;
                }
                lastcid = cid ;

                JSONObject root = new JSONObject();
                JSONArray jarr = new JSONArray();
                jarr.put( obj );
                root.put("data", jarr);
                root.put("length", jarr.length());

                root.put("cid", cid);
                root.put("action",obj.getString("action"));
                root.put("channel" , obj.getString("channel"));
                root.put("sid",obj.getString("sid"));
                root.put("tid",obj.getString("tid"));
                root.put("gid",obj.getString("gid"));

                //global auth add channel
                if ( DBOperator.contactsExist(root) ) {
                    HashSet<String> channArr = getInviteChann2(root);
                    Iterator<String> it = channArr.iterator();
                    while (it.hasNext()) {
                        String chann = it.next();
                        JSONObject tmpchann = new JSONObject();
                        tmpchann.put("channel", chann);

                        //*******************************
                        NoRepeatSubscribe( tmpchann );
                    }

                    if (obj.getString("sid").equals( getSID() )){
                        //sender
                        root.put("who","sender");
                        SenderTask( root  );
                    }else{
                        //reciver
                        root.put("who","reciver");
                        ReciverTask(root  );
                    }

                }else{

                    //invite and reciver
                    if ( obj.has("action") && obj.getString("action").equals("invite") &&  (!obj.getString("sid").equals( getSID()))  ) {

                        //update insert sqlite
                        DBOperator.chatHistoryUpdInsert( root );
                        //refresh syncts table
                        DBOperator.refSyncts();

                        //readed
                        Log.d(TAG , root.toString());
                        sendEBusData( "invite" , root);

                        Log.d(TAG , "EBusService onMqMsg action invite mobile");
                    }

                    //system notify
                    if ( obj.has("action") && obj.getString("action").equals("notify")){
                        //update insert sqlite
                        DBOperator.chatHistoryUpdInsert( root );
                        //refresh syncts table
                        DBOperator.refSyncts();

                        //Log.d(TAG , root.toString());
                        sendLocalBusData( EBusService.NOTIFYSEND , root);
                        Log.d(TAG , "EBusService onMqMsg  action system notify mobile");
                    }

                    // stop flow
                    Log.d(TAG , "user does not exist contacts ");
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };


    private Emitter.Listener OnUnReaded =  new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG , "EBusService OnUnReaded");
            if (args[0] == null ) return ;

            try {

                JSONObject obj = new JSONObject(args[0].toString());

                if (obj.has("initial") && obj.getInt("initial") == 0 ||
                        obj.has("action") && obj.getString("action").equals("invite") ||
                        obj.has("action") && obj.getString("action").equals("notify")) {
                    DBOperator.chatHistoryUpdInsert( obj , true);
                }else {
                    DBOperator.chatHistoryUpdInsert( obj );
                }


                if ( obj.has("action") && obj.getString("action").equals("send")) {
                    Log.d(TAG , "EBusService OnUnReaded action send enter");
                    //QueryUnreadDBSend("mqmsg" , 0 , 100 , true);
                }

                if ( obj.has("action") && obj.getString("action").equals("invite")) {
                    Log.d(TAG , "EBusService OnUnReaded action invite enter");
                    //sendEBusData("invite" , obj );
                }

                if ( obj.has("action") && obj.getString("action").equals("notify")) {
                    Log.d(TAG , "EBusService OnUnReaded notify enter");

                    //notify
                    sendLocalBusData( EBusService.NOTIFYSEND , obj);
                }


                //work task finish
                if (obj.has("action") && obj.getString("action").equals("task")){
                    Log.d(TAG , "EBusService OnUnReaded task finish");

                    if (WeChat.isActive() && TaskCount == 0){
                        new Thread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    Thread.sleep(1200);
                                    JSONObject unreadRecord = DBOperator.chatLastQuery3();
                                    sendEBusData("unreadchattask" , unreadRecord );
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                        }).start();
                        TaskCount++;
                    }

                    //sync
                    new  Thread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                Thread.sleep(7000);
                                DBOperator.refSyncts();
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }).start();


                    int unread = DBOperator.getHistoryUnreadCount();
                    ShortcutBadger.with( getApplicationContext() ).count( unread );
                    Log.d( TAG  , "EBusService OnUnReaded unread:" + unread);
                }

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener OnOpenRoomsed = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG , "EBusService OnOpenRoomsed");
            if (args[0] == null ) return ;
            try {
                JSONObject obj = new JSONObject(args[0].toString());

                //save sqlite
                DBOperator.openRoomsUpdInsert( obj );

            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    };


    private Emitter.Listener OnAsked = new Emitter.Listener(){

        @Override
        public void call(Object... args) {
            Log.d(TAG , "EBusService OnAsked");
            if (args[0] == null ) return ;

            try {
                JSONObject obj = new JSONObject(args[0].toString());
                JSONObject root = new JSONObject();
                JSONArray jarr = new JSONArray();

                jarr.put( obj );
                root.put("data", jarr);
                root.put("length", jarr.length());
                root.remove("device");
                root.put("device", "mobile");
                root.put("action",obj.getString("action"));

                Log.d(TAG , root.toString() );
                //global auth add channel
                if (DBOperator.contactsExist(root)) {
                    HashSet<String> channArr = getInviteChann2(root);
                    Iterator<String> it = channArr.iterator();
                    while (it.hasNext()) {
                        String chann = it.next();
                        JSONObject tmpchann = new JSONObject();
                        tmpchann.put("channel", chann);
                        Log.d(TAG , "ASKED Subscirbe---->" + chann );
                        Subscribe(tmpchann);
                    }

                }else{
                    // stop flow
                    Log.d(TAG , "user does not exist contacts");
                    return;
                }

                Log.d(TAG , obj.toString() );
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    };

    private Emitter.Listener OnSignaled = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG , "EBusService OnSignaled");
            if (args[0] == null ) return ;

        }
    };


    private Emitter.Listener OnSessioned = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG , "EBusService OnSessioned");
            if (args[0] == null ) return ;

        }
    };


    private Emitter.Listener OnSystemed = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG , "EBusService OnSystemed");
            if (args[0] == null ) return ;

        }
    };

    private Emitter.Listener onReconnect = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Log.d(TAG, "onReconnect");

            if (ReConnCount == 0){
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            Thread.sleep(2000);
//                            JSONObject jobj = new JSONObject();
//
//                            Iterator<String> it = channSet.iterator();
//                            while (it.hasNext()){
//                                jobj.remove("channel");
//                                jobj.put("channel", it.next() );
//                                if ( mSocket.connected()) Subscribe( jobj );
//                                jobj.remove("channle");
//                            }
                            MultiSubScribe();
                            ReConnCount = 0;
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }

            ReConnCount++;
        }
    };

    private Emitter.Listener onConnectError = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            JSONObject root = new JSONObject();
            try {
                if ( ConnectErrorTimes > greaterConnectErrorTimes ){
                    stopSelf();
                    return;
                }

                root.put("success", false);
                root.put("msg", "connectError");
                sendEBusData("socket" , root );

                ConnectErrorTimes++;
            } catch (JSONException e) {
                e.printStackTrace();
            }
            Log.d(TAG, "onConnectError");
        }
    };

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        this.stopSelf();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        if ( mSocket != null && mSocket.connected()){
            mSocket.disconnect();
            mSocket.close();
        }
        EventBus.getDefault().unregister(this);
        //activeInstance = 0;
        ClearVariable();
        Log.d(TAG , "EBusService onDestroy");
    }


    public String getDeviceID(){
        try {
            return Settings.Secure.getString( this.getContentResolver(), Settings.Secure.ANDROID_ID);
        }catch (Exception e){
            return  "nulldeviceid";
        }
    }

    private void acquireWakeLock()
    {
        if (null == wakeLock)
        {
            PowerManager pm = (PowerManager)this.getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK|PowerManager.ON_AFTER_RELEASE, "PostLocationService");
            if (null != wakeLock)
            {
                wakeLock.acquire();
            }
        }
    }

    private void releaseWakeLock()
    {
        if (null != wakeLock)
        {
            wakeLock.release();
            wakeLock = null;
        }
    }

    private void initNetworkInfo() {
        if (mNetworkInfo == null) {
            ConnectivityManager mConnectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            mNetworkInfo = mConnectivityManager.getActiveNetworkInfo();
        }
    }
}
