package tw.com.bais.wechat;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by xdna on 2016/5/5.
 */
public class DBHelper extends SQLiteOpenHelper {

    public String TAG = "WeChat";

    public static String chat_history = "CREATE TABLE " +
            DBOperator.chat_history + " ("  +
            "_id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "cid TEXT," +
            "channel TEXT," +
            "action TEXT," +
            "sid TEXT," +

            "tid TEXT," +
            "gid TEXT," +
            "corps INTEGER," +
            "category TEXT," +
            "data TEXT," +

            "status INTEGER," +
            "created_time TEXT," +
            "updated_time TEXT," +
            "location_name TEXT,"+
            "location_address TEXT," +

            "location_phone TEXT," +
            "location_latitude INTEGER," +
            "location_longitude INTEGER," +
            "flag INTEGER)" ;
    public static String drop_chat_history = "DROP TABLE IF EXISTS " + DBOperator.chat_history ;

//    public static String chat = "CREATE TABLE " +
//            DBOperator.chat + " ("  +
//            "channel TEXT PRIMARY KEY," +
//            "sid TEXT ," +
//            "tid TEXT," +
//            "oid TEXT," +
//            "data TEXT," +
//            "chat_name TEXT," +
//            "last_message TEXT," +
//            "last_created_time TEXT," +
//            "isgroup INTEGER," +
//            "unread INTEGER)" ;
//    public static String drop_chat = "DROP TABLE IF EXISTS " + DBOperator.chat ;


    public static String contacts = "CREATE TABLE " +
            DBOperator.contacts + " ("  +
            "m_id TEXT PRIMARY KEY," +
            "custom_name TEXT," +
            "addressbook TEXT," +
            "sex TEXT," +
            "birth TEXT," +

            "email TEXT," +
            "phone TEXT," +
            "mobile TEXT," +
            "grade TEXT," +
            "corps INTEGER," +

            "islock INTEGER," +
            "isgroup INTEGER," +
            "xgroup TEXT," +
            "peonums INTEGER," +
            "picture_path TEXT,"+

            "created_time TEXT,"+
            "updated_time TEXT," +
            "contact_id TEXT," +
            "contact_key TEXT," +
            "status_msg TEXT," +

            "ulast_updated_time TEXT," +
            "glast_updated_time TEXT," +
            "others TEXT )";
    public static String drop_contacts = "DROP TABLE IF EXISTS " + DBOperator.contacts ;


    public static String chat_syncts = "CREATE TABLE " +
            DBOperator.chat_syncts + " ("  +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "channel TEXT," +
            "action TEXT," +
            "last_updated_time TEXT," +
            "isgroup INTEGER," +
            "initial INTEGER )";
    public static String drop_chat_syncts = "DROP TABLE IF EXISTS " + DBOperator.chat_syncts ;



    public static String chat_openrooms = "CREATE TABLE " +
            DBOperator.chat_openrooms + " ("  +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "channel TEXT," +

            "sid TEXT," +
            "starttime TEXT," +
            "endtime TEXT)";
    public static String drop_chat_openrooms = "DROP TABLE IF EXISTS " + DBOperator.chat_openrooms ;



    public static String chat_tsflag = "CREATE TABLE " +
            DBOperator.chat_tsflag + " ("  +
            "flag TEXT PRIMARY KEY," +
            "ts TEXT)";
    public static String drop_chat_tsflag = "DROP TABLE IF EXISTS " + DBOperator.chat_tsflag ;



    public static String chat_news = "CREATE TABLE " +
            DBOperator.chat_news + " ("  +
            "id INTEGER PRIMARY KEY AUTOINCREMENT," +
            "title TEXT ," +
            "content TEXT ," +
            "created_time TEXT)";
    public static String drop_chat_news = "DROP TABLE IF EXISTS " + DBOperator.chat_news ;



    public static String chat_settings = "CREATE TABLE " +
            DBOperator.chat_settings + " ("  +
            "id TEXT PRIMARY KEY ," +
            "serverip TEXT ," +
            "port TEXT ," +
            "hasNotify INTEGER," +
            "notifyTarget TEXT," +
            "notifyTicker TEXT," +
            "notifyTitle TEXT," +
            "hasVibrate INTEGER," +
            "hasSound INTEGER," +
            "hasSaveEl INTEGER," +
            "key TEXT," +
            "fontSize INTEGER )";
    public static String drop_chat_settings = "DROP TABLE IF EXISTS " + DBOperator.chat_settings ;



    public DBHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.d(TAG , "DBhelper drop && create");
        db.execSQL( drop_chat_history );
        db.execSQL( drop_contacts );
        db.execSQL( drop_chat_syncts );
        db.execSQL( drop_chat_openrooms );
        db.execSQL( drop_chat_tsflag );
        db.execSQL( drop_chat_news );
        db.execSQL( drop_chat_settings );

        db.execSQL( chat_history );
        db.execSQL( contacts );
        db.execSQL( chat_syncts );
        db.execSQL( chat_openrooms );
        db.execSQL( chat_tsflag );
        db.execSQL( chat_news );
        db.execSQL( chat_settings);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (newVersion > oldVersion){
            db.execSQL( drop_contacts );
            db.execSQL( drop_chat_settings );
            db.execSQL( contacts );
            db.execSQL( chat_settings);
            Log.d(TAG , "DBHelper onUpgrade");
        }

    }
}
